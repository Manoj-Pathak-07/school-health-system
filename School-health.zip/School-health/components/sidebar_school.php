<?php
// sidebar_school.php - School Admin Sidebar
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-school"></i>
            <span class="logo-text">School Admin</span>
        </div>
        <button class="sidebar-toggle" id="sidebarToggle">
             <i class="fas fa-bars"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <!-- Student Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-users"></i>
                <span>Student</span>
            </div>
            <div class="nav-items">
                <a href="add_student.php" class="nav-item <?= $current_page === 'add_student.php' ? 'active' : '' ?>">
                    <i class="fas fa-user-plus"></i>
                    <span>Add Student</span>
                </a>
                <a href="manage_students.php" class="nav-item <?= $current_page === 'manage_students.php' ? 'active' : '' ?>">
                    <i class="fas fa-user-cog"></i>
                    <span>Manage Students</span>
                </a>
            </div>
        </div>

        <!-- Screening Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-stethoscope"></i>
                <span>Screening</span>
            </div>
            <div class="nav-items">
                <a href="schedule_management.php" class="nav-item <?= $current_page === 'schedule_management.php' ? 'active' : '' ?>">
                    <i class="fas fa-calendar-plus"></i>
                    <span>Create Schedule</span>
                </a>
              
            </div>
        </div>

        <!-- Reports Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </div>
            <div class="nav-items">
                <a href="view_reports.php" class="nav-item <?= $current_page === 'view_reports.php' ? 'active' : '' ?>">
                    <i class="fas fa-file-alt"></i>
                    <span>View All Reports</span>
                </a>
            </div>
        </div>

       
        
    </nav>
</div>