<?php
// sidebar_doctor.php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-user-md"></i>
            <span class="logo-text">Doctor Portal</span>
        </div>
        <button class="sidebar-toggle" id="sidebarToggle">
             <i class="fas fa-bars"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <!-- Health Check Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-heartbeat"></i>
                <span>Health Check</span>
            </div>
            <div class="nav-items">
                <a href="doctor_screening_form.php" class="nav-item <?= $current_page === 'doctor_screening_form.php' ? 'active' : '' ?>">
                    <i class="fas fa-file-medical"></i>
                    <span>Health Report Form</span>
                </a>
            </div>
        </div>

        <!-- Screening Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-calendar-check"></i>
                <span>Screening</span>
            </div>
            <div class="nav-items">
                <a href="screening_schedule.php" class="nav-item <?= $current_page === 'screening_schedule.php' ? 'active' : '' ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Screening Schedule</span>
                </a>
                <a href="screening_records.php" class="nav-item <?= $current_page === 'screening_records.php' ? 'active' : '' ?>">
                    <i class="fas fa-chart-line"></i>
                    <span>Screening Reports</span>
                </a>
            </div>
        </div>
    </nav>
</div>