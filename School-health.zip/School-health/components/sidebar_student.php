<?php
// sidebar_student.php - Student Sidebar
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-user-graduate"></i>
            <span class="logo-text">Student Portal</span>
        </div>
        <button class="sidebar-toggle" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
       

        <!-- Reports Section -->
        <div class="nav-section">
            <div class="nav-section-header">
                <i class="fas fa-file-medical-alt"></i>
                <span>Reports</span>
            </div>
            <div class="nav-items">
                <a href="report_summary.php" class="nav-item <?= $current_page === 'report_summary.php' ? 'active' : '' ?>">
                    <i class="fas fa-chart-pie"></i>
                    <span>Report Summary</span>
                </a>
                
            </div>
        </div>
    </nav>
</div>