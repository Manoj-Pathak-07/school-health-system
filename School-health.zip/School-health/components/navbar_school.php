<?php
// navbar_school.php - School Admin Navbar
?>
<nav class="navbar">
    <div class="navbar-left">
       
        <div class="navbar-brand">
            <i class="fas fa-school"></i>
            <span>School Health System</span>
        </div>
    </div>
    
    <div class="navbar-right">
        <div class="user-info">
            <i class="fas fa-user-shield"></i>
            <span>Logged in as: <?= $_SESSION['full_name'] ?? 'School Admin' ?></span>
        </div>
        <a href="../logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</nav>