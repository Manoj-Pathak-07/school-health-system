<?php
// navbar_student.php - Student Navbar
?>
<nav class="navbar">
    <div class="navbar-left">
        <button class="navbar-toggle" id="navbarToggle">
          
        </button>
        <div class="navbar-brand">
            <i class="fas fa-user-graduate"></i>
            <span>Student Health Portal</span>
        </div>
    </div>
    
    <div class="navbar-right">
        <div class="user-info">
            <i class="fas fa-user"></i>
            <span><?= $_SESSION['full_name'] ?? 'Student' ?> (<?= $_SESSION['grade'] ?? 'Grade' ?>)</span>
        </div>
        <a href="../logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</nav>