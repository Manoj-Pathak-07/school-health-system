// components/scripts.js - Enhanced with smooth animations
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const navbarToggle = document.getElementById('navbarToggle');
    
    // Toggle sidebar with smooth animation
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        
        // Update toggle icon
        const icon = sidebarToggle.querySelector('i');
        if (sidebar.classList.contains('collapsed')) {
            icon.className = 'fas fa-bars';
        } else {
            icon.className = 'fas fa-times';
        }
        
        // Save state in localStorage
        localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
    }
    
    // Mobile sidebar toggle
    function toggleMobileSidebar() {
        sidebar.classList.toggle('mobile-open');
        
        // Add overlay when mobile sidebar is open
        if (sidebar.classList.contains('mobile-open')) {
            createOverlay();
        } else {
            removeOverlay();
        }
    }
    
    // Create overlay for mobile
    function createOverlay() {
        const overlay = document.createElement('div');
        overlay.id = 'sidebar-overlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            backdrop-filter: blur(2px);
        `;
        overlay.addEventListener('click', toggleMobileSidebar);
        document.body.appendChild(overlay);
        document.body.style.overflow = 'hidden';
    }
    
    // Remove overlay
    function removeOverlay() {
        const overlay = document.getElementById('sidebar-overlay');
        if (overlay) {
            overlay.remove();
        }
        document.body.style.overflow = '';
    }
    
    // Event listeners
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }
    
    if (navbarToggle) {
        navbarToggle.addEventListener('click', toggleMobileSidebar);
    }
    
    // Load sidebar state from localStorage
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (isCollapsed) {
        sidebar.classList.add('collapsed');
        const icon = sidebarToggle.querySelector('i');
        if (icon) icon.className = 'fas fa-bars';
    }
    
    // Close sidebar when clicking on nav items on mobile
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 1024) {
                toggleMobileSidebar();
            }
        });
    });
    
    // Active page highlighting
    const currentPage = window.location.pathname.split('/').pop();
    navItems.forEach(item => {
        const href = item.getAttribute('href');
        if (href === currentPage) {
            item.classList.add('active');
        }
    });
    
    // Add hover effects to navbar elements
    const navbarElements = document.querySelectorAll('.navbar-right > *');
    navbarElements.forEach(element => {
        element.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        element.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('mobile-open');
            removeOverlay();
        }
    });
});