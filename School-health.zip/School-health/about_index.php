<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | School Health Screening System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="main_styles.css">
    <link rel="stylesheet" href="about_styles.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8fbff;
        }
        
        nav {
            background: linear-gradient(135deg, #003087, #0055ff);
            padding: 0.8rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 50, 120, 0.3);
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            border-bottom-left-radius: 0.4rem;
            border-bottom-right-radius: 0.4rem;
        }
        
        nav::-webkit-scrollbar {
            display: none;
        }
        /* Hide scrollbar Chrome/Safari */
        
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            flex-shrink: 0;
        }
        
        .shield {
            width: 62px;
            height: 68px;
            flex-shrink: 0;
        }
        
        .logo-text {
            color: white;
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -1.4px;
            white-space: nowrap;
        }
        
        .logo-text span {
            color: #a8d8ff;
        }
        
        .tagline {
            color: #cce5ff;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        /* Menu – Always visible, white text, single line */
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 40px;
            flex-shrink: 0;
            white-space: nowrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 17px;
            position: relative;
            transition: all 0.3s;
        }
        
        .nav-links a:hover {
            color: #e0f2ff;
        }
        
        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 3px;
            bottom: -8px;
            left: 50%;
            background: white;
            border-radius: 3px;
            transition: width 0.4s;
            transform: translateX(-50%);
        }
        
        .nav-links a:hover::after {
            width: 100%;
        }
        /* Login Button */
        
        .login_buttons {
            padding: 0.8rem 1.02rem;
            font-weight: 800;
            color: white;
            border: 1px solid #527fd0;
            /* background-color: #527fd0; */
            background-color: #5d8eea;
            border-radius: 2rem;
            font-family: cursive;
            cursor: pointer;
            transition: 0.5s;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .login_buttons::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            z-index: -1;
            transition: 0.3s;
            /* background-color: #5d8eea; */
            background-color: #527fd0;
        }
        
        .login_buttons:hover::before {
            width: 100%;
        }
        
        .login_buttons>input {
            color: white;
            border: none;
            outline: none;
            background: transparent;
            cursor: pointer;
            font-size: 1.2rem;
        }
        /* Extra small screens – still no hamburger, just horizontal scroll */
        
        @media (max-width: 480px) {
            nav {
                padding: 16px 4%;
                gap: 20px;
            }
            .nav-links {
                gap: 25px;
            }
            .nav-links a {
                font-size: 16px;
            }
            .login-btn {
                padding: 10px 24px;
                font-size: 15px;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->

    <nav>
        <!-- Logo -->
        <a href="#" class="logo">
            <div class="shield">
                <svg viewBox="0 0 100 110" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 8 L90 30 L90 62 C90 90 70 105 50 105 C30 105 10 90 10 62 L10 30 Z" fill="white"/>
          <path d="M50 16 L82 34 L82 58 C82 80 67 94 50 94 C33 94 18 80 18 58 L18 34 Z" fill="#0055ff"/>
          <circle cx="50" cy="36" r="10" fill="white"/>
          <rect x="42" y="46" width="16" height="32" rx="8" fill="white"/>
          <rect x="44" y="76" width="6" height="16" fill="white"/>
          <rect x="50" y="76" width="6" height="16" fill="white"/>
          <rect x="36" y="50" width="28" height="24" rx="6" fill="#a8d8ff"/>
          <rect x="40" y="74" width="20" height="8" rx="3" fill="white"/>
          <rect x="42" y="50" width="4" height="20" fill="white"/>
          <rect x="54" y="50" width="4" height="20" fill="white"/>
        </svg>
            </div>
            <div>
                <div class="logo-text">Student<span>Shield</span></div>
                <div class="tagline">School Health Guardian</div>
            </div>
        </a>

        <!-- Menu & Login – always visible -->
        <div class="nav-links">
            <a href="index.html">Home</a>
            <a href="services_index.html">Services</a>
            <div class="login_buttons">
                <i class="fa-solid fa-user"></i>
                <input type="submit" value="Login">
            </div>
        </div>
    </nav>


    <!-- Hero Section -->


    <section class="hero">
        <div class="container">
            <div class="hero-content fade-in">
                <h1>About Our Health Screening System</h1>
                <p>Empowering schools with digital health monitoring solutions for student wellness</p>

                <div class="hero-stats">
                    <div class="stat-item">
                        <span class="stat-number">0</span>
                        <span class="stat-label">Schools Served</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">0</span>
                        <span class="stat-label">Students Screened</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">0</span>
                        <span class="stat-label">Health Professionals</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about-section">
        <div class="container">
            <h2 class="section-title">Who We Are</h2>
            <p class="section-subtitle">We're dedicated to transforming school health management through innovative technology</p>

            <div class="about-content">
                <div class="about-text">
                    <h3>Transforming School Health Management</h3>
                    <p>The School Health Screening System is a comprehensive digital platform created to help schools track student health efficiently and proactively. Our innovative system bridges the gap between schools, healthcare providers, and students
                        to make health management easy, fast, and reliable.</p>
                    <p>Founded by a team of healthcare professionals and technology experts, we understand the critical importance of early health intervention in educational settings. Our platform is designed to streamline the entire health screening process
                        while maintaining the highest standards of data security and privacy.</p>
                    <p>We believe that healthy students are better learners, and our mission is to support schools in creating environments where every student can thrive physically, mentally, and academically.</p>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1480&q=80" alt="School Health Screening">
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision Section -->
    <section class="mission-vision">
        <div class="container">
            <h2 class="section-title">Our Mission & Vision</h2>
            <p class="section-subtitle">Driving positive change in student healthcare through technology</p>

            <div class="mv-cards">
                <div class="mv-card fade-in">
                    <div class="mv-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Our Mission</h3>
                    <p>To promote student wellness through technology, making health screening seamless with real-time data, medical evaluations, and student-centered reports that enable early intervention and preventive care.</p>
                </div>

                <div class="mv-card fade-in">
                    <div class="mv-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3>Our Vision</h3>
                    <p>To create healthier school communities where every student has access to timely health screenings, preventive care, and health education, ultimately improving academic performance and lifelong wellness.</p>
                </div>

                <div class="mv-card fade-in">
                    <div class="mv-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h3>Our Values</h3>
                    <p>We prioritize student wellbeing, data security, innovation, and collaboration. We believe in empowering schools with tools that make health management efficient, accurate, and accessible to all stakeholders.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2 class="section-title">What We Offer</h2>
            <p class="section-subtitle">Comprehensive health screening solutions tailored for educational institutions</p>

            <div class="features-grid">
                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h3>Doctor Panel</h3>
                    <p>Comprehensive medical screening tools with detailed health forms, BMI auto-calculation, and specialized assessment modules for thorough student evaluations.</p>
                </div>

                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-school"></i>
                    </div>
                    <h3>School Dashboard</h3>
                    <p>Centralized management system for tracking student health records, generating reports, monitoring alerts, and analyzing health trends across the school.</p>
                </div>

                <div class="feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h3>Student Portal</h3>
                    <p>Personalized access for students to view their health reports, receive recommendations, and track their wellness journey over time.</p>
                </div>


            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="team">
        <div class="container">
            <h2 class="section-title">Our Team</h2>

            <div class="team-grid">
                <div class="team-card fade-in">
                    <img src="../images/pk.jpg" alt="Mr.Prakash Oli" class="team-img">
                    <div class="team-info">
                        <h3>Mr.Prakash Oli</h3>
                        <p>BCA 3rd</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-card fade-in">
                    <img src="../images/mnj.jpg" alt="manoj pathak" class="team-img">
                    <div class="team-info">
                        <h3>Mr.Manoj Pathak</h3>
                        <p>BCA 6th</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-card fade-in">
                    <img src="../images/gv.jpg" alt="Gaurav Rana Magar" class="team-img">
                    <div class="team-info">
                        <h3>Mr.Gaurav Magar</h3>
                        <p>BCA 4th</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-card fade-in">
                    <img src="../images/ls.jpg" alt="Laxmi Sharma" class="team-img">
                    <div class="team-info">
                        <h3>Mrs.Laxmi Sharma</h3>
                        <p>BCA 4th</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <div class="footer-logo">
                        <i class="fas fa-stethoscope"></i> School Health Screening
                    </div>
                    <p>Transforming school health management through innovative technology solutions that prioritize student wellness and academic success.</p>
                </div>


                <div class="footer-column">
                    <h3>Contact Us</h3>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt"></i> Kuleshwor 14,Kathmandu Nepal</li>
                        <li><i class="fas fa-phone"></i> +977012548354</li>
                        <li><i class="fas fa-envelope"></i> jmc123@gmail.com</li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2023 School Health Screening System. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>

</html>