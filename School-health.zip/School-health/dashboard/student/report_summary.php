<?php
require_once '../../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_user_id = $_SESSION['user_id'];

// Get student details
$student_sql = "SELECT s.*, u.full_name, u.email 
                FROM students s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.user_id = ?";
$stmt = $pdo->prepare($student_sql);
$stmt->execute([$student_user_id]);
$student = $stmt->fetch();

if (!$student) {
    die("Student not found.");
}

// Get all screening records (latest first)
$records_sql = "SELECT sh.*, dr.full_name as doctor_name 
                FROM screening_history sh 
                JOIN users dr ON sh.doctor_id = dr.id 
                WHERE sh.student_id = ? 
                ORDER BY sh.screening_date DESC";
$records_stmt = $pdo->prepare($records_sql);
$records_stmt->execute([$student['id']]);
$records = $records_stmt->fetchAll();

$latest = $records[0] ?? null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Report Card - <?php echo htmlspecialchars($student['full_name']); ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gray-100: #f9fafb;
            --gray-200: #e5e7eb;
            --gray-600: #4b5563;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        body { font-family: 'Segoe UI', sans-serif; background: #f8fafc; }
        .main-content { margin-left: 280px; padding: 20px; min-height: 100vh; }
        @media (max-width: 768px) { .main-content { margin-left: 0; } }

        .report-container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid var(--gray-200);
        }

        .report-header {
            background: linear-gradient(135deg, var(--primary), #1d4ed8);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .report-header h1 {
            font-size: 2.2rem;
            margin: 0;
            font-weight: 700;
        }

        .report-header p {
            opacity: 0.95;
            font-size: 1.1rem;
            margin-top: 0.5rem;
        }

        .student-info {
            padding: 1.5rem 2rem;
            background: var(--gray-100);
            border-bottom: 1px solid var(--gray-200);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
        }

        .info-item i { color: var(--primary); width: 20px; }

        .report-body {
            padding: 2rem;
        }

        .section {
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.4rem;
            color: var(--gray-900);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .latest-summary {
            background: linear-gradient(120deg, #f0f9ff, #e0f2fe);
            border-radius: 12px;
            padding: 1.5rem;
            border-left: 5px solid var(--primary);
            margin-bottom: 2rem;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .metric-card {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .metric-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary);
        }

        .metric-label {
            color: var(--gray-600);
            font-size: 0.9rem;
            margin-top: 0.3rem;
        }

        .status-good { color: var(--success); }
        .status-warning { color: var(--warning); }
        .status-danger { color: var(--danger); }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            font-size: 0.95rem;
        }

        th {
            background: var(--gray-100);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--gray-800);
            border-bottom: 2px solid var(--primary);
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--gray-200);
        }

        tr:hover {
            background: #f8faff;
        }

        .badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #dbeafe; color: #1e40af; }

        .print-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--primary);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 50px;
            font-size: 1.1rem;
            box-shadow: 0 8px 20px rgba(37,99,235,0.3);
            cursor: pointer;
            z-index: 100;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
        }

        .print-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(37,99,235,0.4);
        }

        @media print {
            body * { visibility: hidden; }
            .report-container, .report-container * { visibility: visible; }
            .report-container { position: absolute; left: 0; top: 0; width: 100%; box-shadow: none; }
            .print-btn, .main-content { display: none; }
        }

        .no-data {
            text-align: center;
            padding: 3rem;
            color: var(--gray-600);
            font-size: 1.1rem;
        }

        .no-data i {
            font-size: 3rem;
            opacity: 0.3;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_student.php'; ?>
    <?php include '../../components/navbar_student.php'; ?>

    <main class="main-content">
        <div class="report-container">
            <!-- Header -->
            <div class="report-header">
                <h1><i class="fas fa-heartbeat"></i> Student Health Report Card</h1>
                <p>Complete Health Screening Summary</p>
            </div>

            <!-- Student Info -->
            <div class="student-info">
                <div class="info-item"><i class="fas fa-user"></i> <strong><?php echo htmlspecialchars($student['full_name']); ?></strong></div>
                <div class="info-item"><i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student['student_code']); ?></div>
                <div class="info-item"><i class="fas fa-school"></i> Grade <?php echo htmlspecialchars($student['grade']); ?></div>
                <div class="info-item"><i class="fas fa-calendar"></i> Report Generated: <?php echo date('j F Y'); ?></div>
            </div>

            <div class="report-body">
                <?php if ($latest): ?>
                    <!-- Latest Screening Summary -->
                    <div class="latest-summary">
                        <h3><i class="fas fa-clipboard-check"></i> Latest Screening - <?php echo date('j F Y', strtotime($latest['screening_date'])); ?></h3>
                        <div class="metrics-grid">
                            <div class="metric-card">
                                <div class="metric-value"><?php echo $latest['height'] ?? '-'; ?> cm</div>
                                <div class="metric-label">Height</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value"><?php echo $latest['weight'] ?? '-'; ?> kg</div>
                                <div class="metric-label">Weight</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value <?php echo $latest['bmi'] < 18.5 ? 'status-warning' : ($latest['bmi'] >= 25 ? 'status-danger' : 'status-good'); ?>">
                                    <?php echo $latest['bmi'] ?? '-'; ?>
                                </div>
                                <div class="metric-label">BMI</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value"><?php echo $latest['vision_status'] ?? 'Normal'; ?></div>
                                <div class="metric-label">Vision</div>
                            </div>
                        </div>

                        <div style="margin-top: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
                            <?php if ($latest['referral_needed']): ?>
                                <span class="badge badge-danger"><i class="fas fa-exclamation-triangle"></i> Referral Needed</span>
                            <?php else: ?>
                                <span class="badge badge-success"><i class="fas fa-check-circle"></i> All Clear</span>
                            <?php endif; ?>

                            <?php if (!empty($latest['recommendations'])): ?>
                                <span class="badge badge-warning"><i class="fas fa-notes-medical"></i> Doctor's Advice Given</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Full History Table -->
                <div class="section">
                    <h2 class="section-title"><i class="fas fa-history"></i> Screening History</h2>

                    <?php if (!empty($records)): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Height/Weight</th>
                                    <th>BMI</th>
                                    <th>Vision</th>
                                    <th>Referral</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($records as $r): ?>
                                    <tr>
                                        <td><?php echo date('j M Y', strtotime($r['screening_date'])); ?></td>
                                        <td><?php echo ucwords(str_replace('_', ' ', $r['screening_type'])); ?></td>
                                        <td><?php echo $r['height'] ?? '-'; ?>/<?php echo $r['weight'] ?? '-'; ?></td>
                                        <td><?php echo $r['bmi'] ?? '-'; ?></td>
                                        <td><?php echo $r['vision_status'] ?? '-'; ?></td>
                                        <td>
                                            <span class="badge <?php echo $r['referral_needed'] ? 'badge-danger' : 'badge-success'; ?>">
                                                <?php echo $r['referral_needed'] ? 'Yes' : 'No'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-info"><?php echo ucfirst($r['status']); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-notes-medical"></i>
                            <h3>No Health Screenings Yet</h3>
                            <p>Your health screening will appear here once completed.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Print Button -->
        <button onclick="window.print()" class="print-btn">
            <i class="fas fa-print"></i> Print Report
        </button>
    </main>

    <script>
        // Optional: Auto-print preview on load
        // window.onload = () => setTimeout(() => window.print(), 1000);
    </script>
</body>
</html>