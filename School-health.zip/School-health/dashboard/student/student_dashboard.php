<?php
session_start();
require_once '../../config.php';

// Check authentication and role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

// Get student data
$student_id = $_SESSION['user_id'];
$student_code = $_SESSION['student_code'] ?? '';
$grade = $_SESSION['grade'] ?? '';
$school_id = $_SESSION['school_id'] ?? '';

// Initialize variables
$student = [];
$school = [];
$screening_stats = ['total_screenings' => 0, 'completed' => 0, 'pending' => 0];
$recent_screenings = [];

try {
    // Get student details from database
    $student_sql = "SELECT s.*, u.full_name, u.email, u.phone 
                   FROM students s 
                   JOIN users u ON s.user_id = u.id 
                   WHERE s.user_id = ?";
    $student_stmt = $pdo->prepare($student_sql);
    $student_stmt->execute([$student_id]);
    $student = $student_stmt->fetch();
    
    if ($student) {
        // Get school name
        $school_sql = "SELECT school_name FROM schools WHERE id = ?";
        $school_stmt = $pdo->prepare($school_sql);
        $school_stmt->execute([$school_id]);
        $school = $school_stmt->fetch();
        
        // Get screening stats
        if (isset($student['id'])) {
            $stats_sql = "SELECT 
                COUNT(*) as total_screenings,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
                FROM screening_history WHERE student_id = ?";
            $stats_stmt = $pdo->prepare($stats_sql);
            $stats_stmt->execute([$student['id']]);
            $screening_stats_result = $stats_stmt->fetch();
            if ($screening_stats_result) {
                $screening_stats = $screening_stats_result;
            }
            
            // Get recent screenings
            $screenings_sql = "SELECT sh.*, d.full_name as doctor_name 
                              FROM screening_history sh 
                              LEFT JOIN doctors d ON sh.doctor_id = d.id 
                              WHERE sh.student_id = ? 
                              ORDER BY sh.screening_date DESC 
                              LIMIT 5";
            $screenings_stmt = $pdo->prepare($screenings_sql);
            $screenings_stmt->execute([$student['id']]);
            $recent_screenings = $screenings_stmt->fetchAll();
        }
    }
    
} catch (PDOException $e) {
    error_log("Student dashboard error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <style>
        .student-welcome {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .student-welcome h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .student-welcome p {
            margin: 0;
            opacity: 0.9;
            font-size: 1.1rem;
        }
        
        .student-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .info-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 4px solid #4CAF50;
        }
        
        .info-card.personal {
            border-left-color: #2196F3;
        }
        
        .info-card.contact {
            border-left-color: #FF9800;
        }
        
        .card-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }
        
        .card-header i {
            font-size: 1.25rem;
            color: currentColor;
        }
        
        .card-header h3 {
            margin: 0;
            color: var(--gray-800);
            font-size: 1.2rem;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: var(--gray-600);
        }
        
        .info-value {
            color: var(--gray-800);
        }
        
        .student-actions {
            margin: 2rem 0;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .action-btn {
            background: white;
            border: 2px solid var(--gray-200);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            text-decoration: none;
            color: var(--gray-700);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
        }
        
        .action-btn:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .action-btn i {
            font-size: 2rem;
            color: var(--primary-color);
        }
        
        .action-btn span {
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .health-tips {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid #9C27B0;
        }
        
        .tips-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .tip-item {
            background: var(--gray-50);
            padding: 1rem;
            border-radius: 8px;
            border-left: 3px solid #4CAF50;
        }
        
        .tip-item h4 {
            margin: 0 0 0.5rem 0;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .tip-item p {
            margin: 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--gray-500);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .student-info-grid {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: 1fr;
            }
            
            .tips-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_student.php'; ?>
    <?php include '../../components/navbar_student.php'; ?>

    <main class="main-content">
        <!-- Welcome Header -->
        <div class="student-welcome fade-in-up">
            <h1>🎓 Welcome, <?php echo htmlspecialchars($student['full_name'] ?? 'Student'); ?>!</h1>
            <p>Manage your health records and view screening activities</p>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card fade-in-up delay-1">
                <div class="stat-icon">
                    <i class="fas fa-stethoscope"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $screening_stats['total_screenings']; ?></div>
                    <div class="stat-label">Total Screenings</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-2">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $screening_stats['completed']; ?></div>
                    <div class="stat-label">Completed</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-3">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $screening_stats['pending']; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-4">
                <div class="stat-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number">Good</div>
                    <div class="stat-label">Health Status</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="student-actions fade-in-up">
            <h3 style="margin-bottom: 20px; color: var(--gray-900);">Quick Actions</h3>
            <div class="actions-grid">
                <a href="view_health_records.php" class="action-btn">
                    <i class="fas fa-heartbeat"></i>
                    <span>Health Records</span>
                </a>
                <a href="view_screenings.php" class="action-btn">
                    <i class="fas fa-clipboard-list"></i>
                    <span>My Screenings</span>
                </a>
                <a href="medical_reports.php" class="action-btn">
                    <i class="fas fa-file-medical"></i>
                    <span>Medical Reports</span>
                </a>
                <a href="profile.php" class="action-btn">
                    <i class="fas fa-user-cog"></i>
                    <span>Profile Settings</span>
                </a>
            </div>
        </div>

        <!-- Student Information Grid -->
        <div class="student-info-grid">
            <!-- Personal Information -->
            <div class="info-card personal fade-in-up delay-2">
                <div class="card-header">
                    <i class="fas fa-user"></i>
                    <h3>Personal Information</h3>
                </div>
                <div class="info-content">
                    <div class="info-item">
                        <span class="info-label">Full Name:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['full_name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Student Code:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student_code); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Grade/Class:</span>
                        <span class="info-value"><?php echo htmlspecialchars($grade); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Date of Birth:</span>
                        <span class="info-value"><?php echo !empty($student['date_of_birth']) ? date('M j, Y', strtotime($student['date_of_birth'])) : 'N/A'; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Gender:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['gender'] ?? 'N/A'); ?></span>
                    </div>
                </div>
            </div>

            <!-- Contact Information -->
            <div class="info-card contact fade-in-up delay-3">
                <div class="card-header">
                    <i class="fas fa-address-book"></i>
                    <h3>Contact Information</h3>
                </div>
                <div class="info-content">
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Phone:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Parent/Guardian:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['parent_name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Parent Phone:</span>
                        <span class="info-value"><?php echo htmlspecialchars($student['parent_phone'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Blood Group:</span>
                        <span class="info-value">
                            <?php 
                            if (!empty($student['address'])) {
                                if (preg_match('/Blood Group:\s*([^\n]+)/', $student['address'], $matches)) {
                                    echo htmlspecialchars(trim($matches[1]));
                                } else {
                                    echo 'Not specified';
                                }
                            } else {
                                echo 'Not specified';
                            }
                            ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Health Screenings -->
        <div class="table-card fade-in-up delay-4">
            <div class="table-header">
                <h3>📋 Recent Health Screenings</h3>
            </div>
            
            <?php if (!empty($recent_screenings)): ?>
            <table class="activity-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Doctor</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recent_screenings as $screening): ?>
                    <tr>
                        <td><?php echo date('M j, Y', strtotime($screening['screening_date'])); ?></td>
                        <td><?php echo htmlspecialchars($screening['screening_type'] ?? 'General'); ?></td>
                        <td><?php echo htmlspecialchars($screening['doctor_name'] ?? 'School Doctor'); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $screening['status'] ?? 'pending'; ?>">
                                <?php echo ucfirst($screening['status'] ?? 'Pending'); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <h3>No Screenings Yet</h3>
                <p>Your health screenings will appear here once scheduled.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Health Tips -->
        <div class="health-tips fade-in-up delay-5">
            <div class="card-header">
                <i class="fas fa-lightbulb"></i>
                <h3>Health Tips</h3>
            </div>
            <div class="tips-grid">
                <div class="tip-item">
                    <h4><i class="fas fa-apple-alt"></i> Nutrition</h4>
                    <p>Eat balanced meals with fruits and vegetables daily for optimal health.</p>
                </div>
                <div class="tip-item">
                    <h4><i class="fas fa-bed"></i> Sleep</h4>
                    <p>Get 8-10 hours of quality sleep each night for better concentration.</p>
                </div>
                <div class="tip-item">
                    <h4><i class="fas fa-running"></i> Exercise</h4>
                    <p>Stay active with at least 60 minutes of physical activity daily.</p>
                </div>
                <div class="tip-item">
                    <h4><i class="fas fa-tint"></i> Hydration</h4>
                    <p>Drink plenty of water throughout the day to stay hydrated.</p>
                </div>
            </div>
        </div>
    </main>

    <script src="../../js/dashboard.js"></script>
</body>
</html>