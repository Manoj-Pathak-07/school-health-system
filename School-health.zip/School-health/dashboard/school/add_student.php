<?php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session
$school_id = $_SESSION['school_id'] ?? 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student - School Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <style>
        /* Additional styles for the form page */
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .form-card {
            background: white;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 1.5rem 2rem;
        }
        
        .form-header h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .form-body {
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--gray-700);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-300);
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        
        .btn-secondary {
            background: var(--gray-300);
            color: var(--gray-700);
        }
        
        .btn-secondary:hover {
            background: var(--gray-400);
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--gray-200);
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #f0fdf4;
            border-color: #bbf7d0;
            color: #166534;
        }
        
        .alert-error {
            background: #fef2f2;
            border-color: #fecaca;
            color: #dc2626;
        }
        
        .auto-credentials {
            background: var(--gray-50);
            padding: 1rem;
            border-radius: var(--border-radius);
            border: 1px solid var(--gray-200);
            margin-bottom: 1.5rem;
        }
        
        .auto-credentials p {
            margin: 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .form-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <div class="form-container">
            <!-- Page Header -->
            <div class="welcome-header fade-in-up">
                <h1>👨‍🎓 Add New Student</h1>
                <p>Register a new student in the health screening system</p>
            </div>

            <!-- Display success/error messages from process file -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type']; ?> fade-in-up">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Student Registration Form -->
            <div class="form-card fade-in-up delay-1">
                <div class="form-header">
                    <h2><i class="fas fa-user-plus"></i> Student Information</h2>
                </div>
                
                <div class="form-body">
                    <!-- Auto-generated credentials info -->
                    <div class="auto-credentials">
                        <p><strong>Note:</strong> Login credentials will be auto-generated - Username: Email, Password: Phone Number</p>
                    </div>

                    <form action="add_student_process.php" method="POST" id="studentForm">
                        <!-- Personal Information Row -->
                        <div class="form-row">
                            <div class="form-group">
                                <label for="full_name" class="form-label">
                                    <i class="fas fa-user"></i> Full Name *
                                </label>
                                <input type="text" id="full_name" name="full_name" class="form-control" 
                                       required placeholder="Enter student's full name">
                            </div>

                            <div class="form-group">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope"></i> Email Address *
                                </label>
                                <input type="email" id="email" name="email" class="form-control" 
                                       required placeholder="student@example.com">
                            </div>
                        </div>

                        <!-- Contact Information Row -->
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone" class="form-label">
                                    <i class="fas fa-phone"></i> Phone Number *
                                </label>
                                <input type="tel" id="phone" name="phone" class="form-control" 
                                       required placeholder="+1234567890">
                            </div>

                            <div class="form-group">
                                <label for="gender" class="form-label">
                                    <i class="fas fa-venus-mars"></i> Gender *
                                </label>
                                <select id="gender" name="gender" class="form-control" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>

                        <!-- Academic Information Row -->
                        <div class="form-row">
                            <div class="form-group">
                                <label for="class" class="form-label">
                                    <i class="fas fa-graduation-cap"></i> Class/Grade *
                                </label>
                                <input type="text" id="class" name="class" class="form-control" 
                                       required placeholder="e.g., Grade 10, Class A">
                            </div>

                            <div class="form-group">
                                <label for="date_of_birth" class="form-label">
                                    <i class="fas fa-calendar-alt"></i> Date of Birth *
                                </label>
                                <input type="date" id="date_of_birth" name="date_of_birth" class="form-control" 
                                       required max="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>

                        <!-- Medical Information -->
                        <div class="form-group">
                            <label for="blood_group" class="form-label">
                                <i class="fas fa-tint"></i> Blood Group
                            </label>
                            <select id="blood_group" name="blood_group" class="form-control">
                                <option value="">Select Blood Group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                                <option value="Unknown">Unknown</option>
                            </select>
                        </div>

                        <!-- Form Actions -->
                        <div class="form-actions">
                            <a href="school_dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Dashboard
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Add Student
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Form validation and enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('studentForm');
            
            // Real-time validation
            form.addEventListener('submit', function(e) {
                let isValid = true;
                const requiredFields = form.querySelectorAll('[required]');
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.style.borderColor = '#ef4444';
                    } else {
                        field.style.borderColor = '#d1d5db';
                    }
                });
                
                // Email validation
                const emailField = document.getElementById('email');
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (emailField.value && !emailRegex.test(emailField.value)) {
                    isValid = false;
                    emailField.style.borderColor = '#ef4444';
                    alert('Please enter a valid email address');
                }
                
                // Phone validation (basic)
                const phoneField = document.getElementById('phone');
                const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
                if (phoneField.value && !phoneRegex.test(phoneField.value.replace(/\s/g, ''))) {
                    isValid = false;
                    phoneField.style.borderColor = '#ef4444';
                    alert('Please enter a valid phone number');
                }
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Please fill in all required fields correctly.');
                }
            });
            
            // Date of birth max validation (should not be future date)
            const dobField = document.getElementById('date_of_birth');
            dobField.max = new Date().toISOString().split('T')[0];
        });
    </script>
</body>
</html>