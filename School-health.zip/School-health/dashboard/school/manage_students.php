<?php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session
$school_id = $_SESSION['school_id'] ?? 1;

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$class_filter = $_GET['class'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Build query for students
$query = "SELECT s.*, u.full_name, u.email, u.phone, u.is_active 
          FROM students s 
          JOIN users u ON s.user_id = u.id 
          WHERE s.school_id = ?";
$params = [$school_id];

// Add search filter
if (!empty($search)) {
    $query .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR s.student_code LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

// Add class filter
if (!empty($class_filter)) {
    $query .= " AND s.grade = ?";
    $params[] = $class_filter;
}



// Order by user creation date instead of student created_at
$query .= " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique classes for filter dropdown
$class_query = "SELECT DISTINCT grade FROM students WHERE school_id = ? ORDER BY grade";
$class_stmt = $pdo->prepare($class_query);
$class_stmt->execute([$school_id]);
$classes = $class_stmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - School Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <style>
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .filters-container {
            background: white;
            padding: 1.5rem;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            margin-bottom: 2rem;
        }
        
        .filters-row {
            display: grid;
            grid-template-columns: 1fr auto auto;
            gap: 1rem;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-label {
            font-weight: 500;
            color: var(--gray-700);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-300);
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        
        .btn-secondary {
            background: var(--gray-300);
            color: var(--gray-700);
        }
        
        .btn-secondary:hover {
            background: var(--gray-400);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background: #dc2626;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }
        
        .students-grid {
            display: grid;
            gap: 1.5rem;
        }
        
        .student-card {
            background: white;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .student-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }
        
        .student-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .student-code {
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-active {
            background: rgba(34, 197, 94, 0.2);
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }
        
        .status-inactive {
            background: rgba(239, 68, 68, 0.2);
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        .student-body {
            padding: 1.5rem;
        }
        
        .student-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-label {
            font-size: 0.875rem;
            color: var(--gray-500);
            margin-bottom: 0.25rem;
        }
        
        .info-value {
            font-weight: 500;
            color: var(--gray-800);
        }
        
        .student-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray-500);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #f0fdf4;
            border-color: #bbf7d0;
            color: #166534;
        }
        
        .alert-error {
            background: #fef2f2;
            border-color: #fecaca;
            color: #dc2626;
        }
        
        @media (max-width: 768px) {
            .filters-row {
                grid-template-columns: 1fr;
            }
            
            .student-info {
                grid-template-columns: 1fr;
            }
            
            .student-actions {
                flex-direction: column;
            }
            
            .student-actions .btn {
                justify-content: center;
            }
        }
        
        @media (min-width: 1024px) {
            .students-grid {
                grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <div class="welcome-header fade-in-up">
                    <h1>👨‍🎓 Manage Students</h1>
                    <p>View, edit, and manage student records</p>
                </div>
                <a href="add_student.php" class="btn btn-primary fade-in-up">
                    <i class="fas fa-user-plus"></i> Add New Student
                </a>
            </div>

            <!-- Display messages -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type']; ?> fade-in-up">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="filters-container fade-in-up delay-1">
                <form method="GET" action="">
                    <div class="filters-row">
                        <div class="filter-group">
                            <label class="filter-label">Search Students</label>
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Search by name, email, or student code..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        
                        <div class="filter-group">
                            <label class="filter-label">Filter by Class</label>
                            <select name="class" class="form-control">
                                <option value="">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo htmlspecialchars($class); ?>" 
                                        <?php echo $class_filter === $class ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($class); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label class="filter-label">Filter by Status</label>
                            <select name="status" class="form-control">
                                <option value="">All Status</option>
                                <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Apply Filters
                            </button>
                            <?php if ($search || $class_filter || $status_filter): ?>
                                <a href="manage_students.php" class="btn btn-secondary" style="margin-top: 0.5rem;">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Students Grid -->
            <div class="students-grid fade-in-up delay-2">
                <?php if (empty($students)): ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No Students Found</h3>
                        <p><?php echo ($search || $class_filter || $status_filter) ? 
                            'Try adjusting your filters or search terms.' : 
                            'Get started by adding your first student.'; ?></p>
                        <?php if (!($search || $class_filter || $status_filter)): ?>
                            <a href="add_student.php" class="btn btn-primary">
                                <i class="fas fa-user-plus"></i> Add Student
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <?php foreach ($students as $student): ?>
                        <div class="student-card">
                            <div class="student-header">
                                <div class="student-code"><?php echo htmlspecialchars($student['student_code']); ?></div>
                                <div class="status-badge status-<?php echo $student['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $student['is_active'] ? 'Active' : 'Inactive'; ?>
                                </div>
                            </div>
                            
                            <div class="student-body">
                                <div class="student-info">
                                    <div class="info-item">
                                        <span class="info-label">Full Name</span>
                                        <span class="info-value"><?php echo htmlspecialchars($student['full_name']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Email</span>
                                        <span class="info-value"><?php echo htmlspecialchars($student['email']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Phone</span>
                                        <span class="info-value"><?php echo htmlspecialchars($student['phone']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Class/Grade</span>
                                        <span class="info-value"><?php echo htmlspecialchars($student['grade']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Gender</span>
                                        <span class="info-value"><?php echo htmlspecialchars($student['gender']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Date of Birth</span>
                                        <span class="info-value"><?php echo !empty($student['date_of_birth']) ? date('M j, Y', strtotime($student['date_of_birth'])) : 'Not set'; ?></span>
                                    </div>
                                </div>
                                
                                <div class="student-actions">
                                    <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-secondary btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="view_student.php?id=<?php echo $student['id']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <?php if ($student['is_active']): ?>
                                        <a href="delete_student.php?id=<?php echo $student['id']; ?>" 
   class="btn btn-danger btn-sm"
   onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars($student['full_name']); ?>? This action cannot be undone.')">
    <i class="fas fa-trash"></i> Delete
</a>
                                    <?php else: ?>
              <a href="force_delete_student.php?id=<?php echo $student['id']; ?>" 
   class="btn btn-danger btn-sm"
   onclick="return confirm('WARNING: This will permanently delete <?php echo htmlspecialchars($student['full_name']); ?> and ALL their screening records. This action cannot be undone! Are you sure?')">
    <i class="fas fa-trash"></i> Force Delete
</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script>
        // Auto-submit form when filters change (optional)
        document.addEventListener('DOMContentLoaded', function() {
            const classSelect = document.querySelector('select[name="class"]');
            const statusSelect = document.querySelector('select[name="status"]');
            
            [classSelect, statusSelect].forEach(select => {
                if (select) {
                    select.addEventListener('change', function() {
                        this.form.submit();
                    });
                }
            });
        });
    </script>
</body>
</html>