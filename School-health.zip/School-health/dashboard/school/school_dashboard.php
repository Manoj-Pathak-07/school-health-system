<?php

require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session or database
$school_id = $_SESSION['school_id'] ?? 1; // Fallback to 1 for demo

// Get real data from database
$stats = getSchoolStats($school_id);
$recent_activities = getRecentActivities($school_id, 5);

// Define default values for all required stats
$default_stats = [
    'total_students' => 0,
    'screenings_completed' => 0,
    'pending_screenings' => 0,
    'upcoming_screenings' => 0
];

// Merge with default values to ensure all keys exist
if ($stats) {
    $stats = array_merge($default_stats, $stats);
} else {
    $stats = $default_stats;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Dashboard - Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <!-- Welcome Header -->
        <div class="welcome-header fade-in-up">
            <h1>🏫 Welcome, School Administrator!</h1>
            <p>Manage student health screenings and monitor school health analytics</p>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card fade-in-up delay-1">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $stats['total_students']; ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-2">
                <div class="stat-icon">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $stats['screenings_completed']; ?></div>
                    <div class="stat-label">Screenings Completed</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-3">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $stats['pending_screenings']; ?></div>
                    <div class="stat-label">Pending Screenings</div>
                </div>
            </div>

            <div class="stat-card fade-in-up delay-4">
                <div class="stat-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $stats['upcoming_screenings']; ?></div>
                    <div class="stat-label">Upcoming This Week</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions fade-in-up">
            <h3 style="margin-bottom: 20px; color: var(--gray-900);">Quick Actions</h3>
            <div class="actions-grid">
                <a href="add_student.php" class="action-btn">
                    <i class="fas fa-user-plus"></i>
                    <span>Add New Student</span>
                </a>
                <a href="create_schedule.php" class="action-btn">
                    <i class="fas fa-calendar-plus"></i>
                    <span>Schedule Screening</span>
                </a>
                <a href="view_reports.php" class="action-btn">
                    <i class="fas fa-file-alt"></i>
                    <span>View Reports</span>
                </a>
                <a href="manage_doctors.php" class="action-btn">
                    <i class="fas fa-user-md"></i>
                    <span>Manage Doctors</span>
                </a>
            </div>
        </div>

        <!-- Recent Activity -->
        <?php if (!empty($recent_activities)): ?>
        <div class="table-card fade-in-up">
            <div class="table-header">
                <h3>📋 Recent Screening Activities</h3>
            </div>
            <table class="activity-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Grade</th>
                        <th>Date</th>
                        <th>Doctor</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recent_activities as $activity): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($activity['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($activity['grade']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($activity['screening_date'])); ?></td>
                        <td><?php echo htmlspecialchars($activity['doctor_name']); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $activity['status']; ?>">
                                <?php echo ucfirst($activity['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="table-card fade-in-up">
            <div class="table-header">
                <h3>📋 Recent Screening Activities</h3>
            </div>
            <div style="padding: 40px; text-align: center; color: var(--gray-600);">
                <i class="fas fa-clipboard-list" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.5;"></i>
                <p>No screening activities found. Schedule your first screening to get started.</p>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <script src="../js/dashboard.js"></script>
</body>
</html>