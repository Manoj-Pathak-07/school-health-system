<?php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session
$school_id = $_SESSION['school_id'] ?? 1;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['student_ids']) && isset($_POST['doctor_id'])) {
        $student_ids = $_POST['student_ids'];
        $doctor_id = $_POST['doctor_id'];
        $schedule_date = $_POST['schedule_date'];
        $schedule_time = $_POST['schedule_time'];
        $screening_type = $_POST['screening_type'];
        
        try {
            $pdo->beginTransaction();
            
            foreach ($student_ids as $student_id) {
                $stmt = $pdo->prepare("INSERT INTO screening_schedule (student_id, doctor_id, school_id, schedule_date, schedule_time, screening_type) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $doctor_id, $school_id, $schedule_date, $schedule_time, $screening_type]);
            }
            
            $pdo->commit();
            $success_message = count($student_ids) . " schedule(s) created successfully!";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error_message = "Error creating schedules: " . $e->getMessage();
        }
    } else {
        $error_message = "Please select at least one student and a doctor.";
    }
}

// Fetch students and doctors for dropdowns
try {
    // Get students with their names from users table
    $students_query = "
        SELECT s.id, u.full_name, s.grade, s.student_code 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        WHERE s.school_id = ? 
        ORDER BY u.full_name
    ";
    $students = $pdo->prepare($students_query);
    $students->execute([$school_id]);
    $students_data = $students->fetchAll(PDO::FETCH_ASSOC);
    
    // Get doctors from users table
    $doctors = $pdo->prepare("SELECT id, full_name FROM users WHERE role = 'doctor' AND is_active = 1 ORDER BY full_name");
    $doctors->execute();
    $doctors_data = $doctors->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error_message = "Error loading data: " . $e->getMessage();
    $students_data = [];
    $doctors_data = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Schedule - Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <style>
        /* Simple CSS to ensure button displays */
        .form-container {
            padding: 30px;
        }

        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1e293b;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .students-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .student-checkbox {
            position: relative;
        }

        .student-checkbox-input {
            position: absolute;
            opacity: 0;
        }

        .student-checkbox-label {
            display: block;
            padding: 15px;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .student-checkbox-input:checked + .student-checkbox-label {
            border-color: #3b82f6;
            background: #dbeafe;
        }

        .student-checkbox-label:hover {
            border-color: #60a5fa;
        }

        .student-info strong {
            display: block;
            margin-bottom: 5px;
            color: #1e293b;
        }

        .student-details {
            display: flex;
            justify-content: space-between;
            font-size: 0.85rem;
            color: #64748b;
        }

        .selection-count {
            padding: 10px 15px;
            background: #f1f5f9;
            border-radius: 6px;
            text-align: center;
            font-size: 0.9rem;
            margin-bottom: 20px;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary {
            background: #3b82f6;
            color: white;
        }

        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
        }

        .btn-sm {
            padding: 8px 15px;
            font-size: 14px;
        }

        /* Make sure save button is visible */
        .btn-save {
            background: #10b981 !important;
            color: white !important;
            padding: 14px 30px !important;
            font-size: 16px !important;
            border: none !important;
        }

        .btn-save:hover {
            background: #059669 !important;
            transform: translateY(-1px) !important;
        }

        @media (min-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .students-grid {
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <div class="container" style="max-width: 1000px; margin: 0 auto;">
            
            <!-- Page Header -->
            <div class="welcome-header fade-in-up">
                <h1>➕ Create Health Checkup Schedule</h1>
                <p>Schedule health screenings for multiple students</p>
            </div>

            <!-- Notifications -->
            <?php if (isset($success_message)): ?>
            <div class="alert alert-success fade-in-up" style="background: #dcfce7; color: #166534; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #16a34a;">
                <i class="fas fa-check-circle"></i>
                <?php echo $success_message; ?>
            </div>
            <?php endif; ?>

            <?php if (isset($error_message)): ?>
            <div class="alert alert-error fade-in-up" style="background: #fecaca; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #dc2626;">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error_message; ?>
            </div>
            <?php endif; ?>

            <!-- Schedule Form -->
            <div class="table-card fade-in-up" style="background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div class="table-header" style="background: #3b82f6; color: white; padding: 20px 30px; border-radius: 12px 12px 0 0;">
                    <h3 style="margin: 0;">📋 Schedule Details</h3>
                </div>
                
                <form method="POST" class="form-container">
                    <!-- Schedule Information -->
                    <div class="form-section">
                        <h4 style="margin-bottom: 20px; color: #374151;">
                            <i class="fas fa-calendar-alt"></i> Schedule Information
                        </h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="doctor_id">Assign Doctor *</label>
                                <select id="doctor_id" name="doctor_id" class="form-control" required>
                                    <option value="">Select Doctor</option>
                                    <?php foreach($doctors_data as $doctor): ?>
                                    <option value="<?php echo $doctor['id']; ?>">
                                        Dr. <?php echo htmlspecialchars($doctor['full_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="schedule_date">Date *</label>
                                <input type="date" id="schedule_date" name="schedule_date" class="form-control" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="schedule_time">Time *</label>
                                <input type="time" id="schedule_time" name="schedule_time" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="screening_type">Checkup Type *</label>
                                <select id="screening_type" name="screening_type" class="form-control" required>
                                    <option value="">Select Type</option>
                                    <option value="Regular Checkup">Regular Health Checkup</option>
                                    <option value="Annual Screening">Annual Health Screening</option>
                                    <option value="Sports Physical">Sports Physical</option>
                                    <option value="Vision Test">Vision Test</option>
                                    <option value="Dental Checkup">Dental Checkup</option>
                                    <option value="Vaccination">Vaccination</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Student Selection -->
                    <div class="form-section">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <h4 style="color: #374151; margin: 0;">
                                <i class="fas fa-users"></i> Select Students
                            </h4>
                            <div>
                                <button type="button" id="selectAll" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-check-double"></i> Select All
                                </button>
                                <button type="button" id="deselectAll" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-times"></i> Deselect All
                                </button>
                            </div>
                        </div>

                        <?php if (!empty($students_data)): ?>
                        <div class="students-grid">
                            <?php foreach($students_data as $student): ?>
                            <div class="student-checkbox">
                                <input type="checkbox" name="student_ids[]" value="<?php echo $student['id']; ?>" 
                                       id="student_<?php echo $student['id']; ?>" class="student-checkbox-input">
                                <label for="student_<?php echo $student['id']; ?>" class="student-checkbox-label">
                                    <div class="student-info">
                                        <strong><?php echo htmlspecialchars($student['full_name']); ?></strong>
                                        <div class="student-details">
                                            <span>Grade: <?php echo htmlspecialchars($student['grade']); ?></span>
                                            <span>ID: <?php echo htmlspecialchars($student['student_code']); ?></span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="selection-count" id="selectionCount">
                            No students selected
                        </div>
                        <?php else: ?>
                        <div style="padding: 40px; text-align: center; color: #64748b;">
                            <i class="fas fa-users-slash" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.5;"></i>
                            <p>No students found in your school.</p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- SAVE BUTTON - Made very clear and visible -->
                    <div class="form-actions">
                        <a href="schedule_management.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Schedules
                        </a>
                        <button type="submit" class="btn btn-save" style="background: #10b981; color: white; padding: 14px 30px; font-size: 16px; border: none; border-radius: 8px; cursor: pointer;">
                            <i class="fas fa-save"></i> SAVE SCHEDULE
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script>
        // Set default date to today
        document.getElementById('schedule_date').value = '<?php echo date('Y-m-d'); ?>';
        
        // Set minimum time to current time for today's date
        document.getElementById('schedule_date').addEventListener('change', function() {
            const timeInput = document.getElementById('schedule_time');
            const selectedDate = new Date(this.value);
            const today = new Date();
            
            if (selectedDate.toDateString() === today.toDateString()) {
                const now = new Date();
                const hours = now.getHours().toString().padStart(2, '0');
                const minutes = now.getMinutes().toString().padStart(2, '0');
                timeInput.min = `${hours}:${minutes}`;
            } else {
                timeInput.min = '00:00';
            }
        });

        // Select All functionality
        document.getElementById('selectAll').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.student-checkbox-input');
            checkboxes.forEach(checkbox => checkbox.checked = true);
            updateSelectionCount();
        });

        document.getElementById('deselectAll').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.student-checkbox-input');
            checkboxes.forEach(checkbox => checkbox.checked = false);
            updateSelectionCount();
        });

        // Update selection count
        function updateSelectionCount() {
            const selectedCount = document.querySelectorAll('.student-checkbox-input:checked').length;
            const countElement = document.getElementById('selectionCount');
            countElement.textContent = `${selectedCount} student(s) selected`;
            
            if (selectedCount > 0) {
                countElement.style.color = '#16a34a';
                countElement.style.fontWeight = '600';
            } else {
                countElement.style.color = '#64748b';
                countElement.style.fontWeight = 'normal';
            }
        }

        // Add event listeners to all checkboxes
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.student-checkbox-input');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateSelectionCount);
            });
            updateSelectionCount();
        });

        // Form validation before submit
        document.querySelector('form').addEventListener('submit', function(e) {
            const selectedStudents = document.querySelectorAll('.student-checkbox-input:checked').length;
            const doctorSelected = document.getElementById('doctor_id').value;
            
            if (selectedStudents === 0) {
                e.preventDefault();
                alert('Please select at least one student.');
                return false;
            }
            
            if (!doctorSelected) {
                e.preventDefault();
                alert('Please select a doctor.');
                return false;
            }
        });
    </script>
</body>
</html>