<?php
session_start();
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    $_SESSION['message'] = "Please login to access this page.";
    $_SESSION['message_type'] = 'error';
    header("Location: ../login.php");
    exit;
}

$school_id = $_SESSION['school_id'] ?? 1;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get form data
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $class = trim($_POST['class'] ?? '');
    $date_of_birth = trim($_POST['date_of_birth'] ?? '');
    $blood_group = trim($_POST['blood_group'] ?? '');
    
    // Validate required fields
    $errors = [];
    if (empty($full_name)) $errors[] = "Full name is required.";
    if (empty($email)) $errors[] = "Email address is required.";
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email address.";
    if (empty($phone)) $errors[] = "Phone number is required.";
    if (empty($gender)) $errors[] = "Gender is required.";
    if (empty($class)) $errors[] = "Class/Grade is required.";
    if (empty($date_of_birth)) $errors[] = "Date of birth is required.";
    elseif (strtotime($date_of_birth) > time()) $errors[] = "Date of birth cannot be in the future.";
    
    if (empty($errors)) {
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Step 1: Check if user already exists
            $check_user_sql = "SELECT id FROM users WHERE email = ?";
            $check_user_stmt = $pdo->prepare($check_user_sql);
            $check_user_stmt->execute([$email]);
            
            if ($check_user_stmt->fetch()) {
                throw new Exception("A user with this email already exists.");
            }
            
            // Step 2: Create user account - USING YOUR EXACT COLUMNS
            $password = $phone; // Using phone as password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $user_sql = "INSERT INTO users (email, password, full_name, phone, role, is_active, created_at) 
                         VALUES (?, ?, ?, ?, 'student', 1, NOW())";
            $user_stmt = $pdo->prepare($user_sql);
            $user_stmt->execute([$email, $hashed_password, $full_name, $phone]);
            
            $user_id = $pdo->lastInsertId();
            
            // Step 3: Generate student code
            $student_code = 'STU' . date('YmdHis') . rand(100, 999);
            
            // Step 4: Create student record
            $address = "Parent: $full_name\nGrade: $class\nEmail: $email";
            if (!empty($blood_group)) {
                $address .= "\nBlood Group: $blood_group";
            }
            
            $student_sql = "INSERT INTO students (
                user_id, school_id, student_code, grade, date_of_birth, 
                gender, parent_name, parent_phone, address
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $student_stmt = $pdo->prepare($student_sql);
            $student_stmt->execute([
                $user_id, $school_id, $student_code, $class, $date_of_birth,
                $gender, $full_name, $phone, $address
            ]);
            
            $student_id = $pdo->lastInsertId();
            
            // Commit transaction
            $pdo->commit();
            
            // Success message
            $_SESSION['message'] = "🎉 Student added successfully!<br><br>
            <strong>Student Details:</strong><br>
            • Parent/Guardian: " . htmlspecialchars($full_name) . "<br>
            • Student Code: " . htmlspecialchars($student_code) . "<br>
            • Grade: " . htmlspecialchars($class) . "<br>
            • Email: " . htmlspecialchars($email) . "<br><br>
            <strong>Login Credentials:</strong><br>
            • Email: " . htmlspecialchars($email) . "<br>
            • Password: " . htmlspecialchars($phone) . "<br><br>
            <em>Student can now login using these credentials!</em>";
            $_SESSION['message_type'] = 'success';
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $pdo->rollBack();
            
            $_SESSION['message'] = "Error: " . $e->getMessage();
            $_SESSION['message_type'] = 'error';
        }
    } else {
        $_SESSION['message'] = implode("<br>", $errors);
        $_SESSION['message_type'] = 'error';
    }
    
    header("Location: add_student.php");
    exit;
} else {
    header("Location: add_student.php");
    exit;
}