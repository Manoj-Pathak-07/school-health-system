<?php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

$school_id = $_SESSION['school_id'] ?? 1;

if (!isset($_GET['id'])) {
    header("Location: manage_students.php");
    exit;
}

$student_id = $_GET['id'];

// Get student details
$query = "SELECT s.*, u.full_name, u.email, u.phone, u.is_active, u.created_at as user_created
          FROM students s 
          JOIN users u ON s.user_id = u.id 
          WHERE s.id = ? AND s.school_id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$student_id, $school_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $_SESSION['message'] = "Student not found or access denied.";
    $_SESSION['message_type'] = 'error';
    header("Location: manage_students.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student - School Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../css/components.css" rel="stylesheet">
    <link href="../../css/dashboard.css" rel="stylesheet">
    <style>
        .student-profile {
            max-width: 1000px;
            margin: 0 auto;
        }
        
        .profile-header {
            background: white;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .profile-banner {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .profile-info h1 {
            margin: 0;
            font-size: 1.75rem;
            font-weight: 600;
        }
        
        .profile-actions {
            display: flex;
            gap: 1rem;
        }
        
        .profile-details {
            padding: 2rem;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }
        
        .detail-section {
            background: var(--gray-50);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            border: 1px solid var(--gray-200);
        }
        
        .detail-section h3 {
            margin: 0 0 1rem 0;
            color: var(--primary-color);
            font-size: 1.1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .detail-item:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: 500;
            color: var(--gray-600);
        }
        
        .detail-value {
            color: var(--gray-800);
            font-weight: 500;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-active {
            background: rgba(34, 197, 94, 0.2);
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }
        
        .status-inactive {
            background: rgba(239, 68, 68, 0.2);
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        
        .btn-secondary {
            background: var(--gray-300);
            color: var(--gray-700);
        }
        
        .btn-secondary:hover {
            background: var(--gray-400);
        }
        
        @media (max-width: 768px) {
            .profile-banner {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .profile-actions {
                width: 100%;
                justify-content: space-between;
            }
            
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <div class="student-profile">
            <!-- Display messages -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type']; ?> fade-in-up">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Student Profile -->
            <div class="profile-header fade-in-up">
                <div class="profile-banner">
                    <div class="profile-info">
                        <h1><?php echo htmlspecialchars($student['full_name']); ?></h1>
                        <p>Student Code: <?php echo htmlspecialchars($student['student_code']); ?></p>
                        <div class="status-badge status-<?php echo $student['is_active'] ? 'active' : 'inactive'; ?>">
                            <?php echo $student['is_active'] ? 'Active Student' : 'Inactive Student'; ?>
                        </div>
                    </div>
                    <div class="profile-actions">
                        <a href="manage_students.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Students
                        </a>
                        <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Edit Student
                        </a>
                    </div>
                </div>
                
                <div class="profile-details">
                    <div class="details-grid">
                        <!-- Personal Information -->
                        <div class="detail-section">
                            <h3><i class="fas fa-user"></i> Personal Information</h3>
                            <div class="detail-item">
                                <span class="detail-label">Full Name</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['full_name']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Email</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['email']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Phone</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['phone']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Gender</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['gender']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Date of Birth</span>
                                <span class="detail-value"><?php echo !empty($student['date_of_birth']) ? date('F j, Y', strtotime($student['date_of_birth'])) : 'Not set'; ?></span>
                            </div>
                        </div>

                        <!-- Academic Information -->
                        <div class="detail-section">
                            <h3><i class="fas fa-graduation-cap"></i> Academic Information</h3>
                            <div class="detail-item">
                                <span class="detail-label">Student Code</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['student_code']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Class/Grade</span>
                                <span class="detail-value"><?php echo htmlspecialchars($student['grade']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Account Status</span>
                                <span class="detail-value"><?php echo $student['is_active'] ? 'Active' : 'Inactive'; ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Account Created</span>
                                <span class="detail-value"><?php echo date('F j, Y g:i A', strtotime($student['user_created'])); ?></span>
                            </div>
                        </div>

                        <!-- Parent/Guardian Information -->
                        <div class="detail-section">
                            <h3><i class="fas fa-users"></i> Parent/Guardian Information</h3>
                            <div class="detail-item">
                                <span class="detail-label">Parent Name</span>
                                <span class="detail-value"><?php echo !empty($student['parent_name']) ? htmlspecialchars($student['parent_name']) : 'Not set'; ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Parent Phone</span>
                                <span class="detail-value"><?php echo !empty($student['parent_phone']) ? htmlspecialchars($student['parent_phone']) : 'Not set'; ?></span>
                            </div>
                        </div>

                        <!-- Additional Information -->
                        <?php if (!empty($student['address'])): ?>
                        <div class="detail-section">
                            <h3><i class="fas fa-info-circle"></i> Additional Information</h3>
                            <div class="detail-item" style="flex-direction: column; align-items: flex-start;">
                                <span class="detail-label">Address & Notes</span>
                                <span class="detail-value" style="margin-top: 0.5rem; white-space: pre-line;"><?php echo htmlspecialchars($student['address']); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>