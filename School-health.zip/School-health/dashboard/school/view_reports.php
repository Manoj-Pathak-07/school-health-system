<?php
require_once '../../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school-wide statistics
$total_students = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();

$completed_screenings = $pdo->query("SELECT COUNT(*) FROM screening_history WHERE status = 'completed'")->fetchColumn();
$pending_screenings = $pdo->query("SELECT COUNT(*) FROM screening_history WHERE status = 'pending'")->fetchColumn();
$referral_needed = $pdo->query("SELECT COUNT(*) FROM screening_history WHERE referral_needed = 1 AND status = 'completed'")->fetchColumn();
$normal_health = $pdo->query("SELECT COUNT(*) FROM screening_history WHERE referral_needed = 0 AND status = 'completed'")->fetchColumn();

// Grade-wise summary
$grade_stats = $pdo->query("
    SELECT s.grade, 
           COUNT(sh.id) as screened,
           SUM(CASE WHEN sh.referral_needed = 1 THEN 1 ELSE 0 END) as needs_referral
    FROM students s
    LEFT JOIN screening_history sh ON s.id = sh.student_id AND sh.status = 'completed'
    GROUP BY s.grade
    ORDER BY s.grade
")->fetchAll();

// Recent screenings
$recent = $pdo->query("
    SELECT sh.screening_date, sh.screening_type, 
           u.full_name as student_name, s.student_code, s.grade,
           sh.referral_needed, sh.status
    FROM screening_history sh
    JOIN students s ON sh.student_id = s.id
    JOIN users u ON s.user_id = u.id
    ORDER BY sh.screening_date DESC, sh.created_at DESC
    LIMIT 15
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Health Report - Admin Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gray-100: #f9fafb;
            --gray-200: #e5e7eb;
            --gray-600: #4b5563;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        .main-content {
            margin-left: 280px;
            padding: 20px;
            background: #f8fafc;
            min-height: 100vh;
        }
        @media (max-width: 768px) {
            .main-content { margin-left: 0; }
        }

        .report-container {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid var(--gray-200);
        }

        .report-header {
            background: linear-gradient(135deg, #1e40af, #2563eb);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .report-header h1 {
            font-size: 2.4rem;
            margin: 0;
            font-weight: 700;
        }

        .report-header p {
            font-size: 1.1rem;
            opacity: 0.95;
            margin-top: 0.5rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            padding: 2rem;
            background: var(--gray-100);
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
        }

        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--primary);
        }

        .stat-label {
            color: var(--gray-600);
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .report-body {
            padding: 2rem;
        }

        .section {
            margin-bottom: 2.5rem;
        }

        .section-title {
            font-size: 1.5rem;
            color: var(--gray-900);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 3px solid var(--primary);
            display: inline-block historiography;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            font-size: 0.95rem;
        }

        th {
            background: var(--gray-100);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--gray-800);
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--gray-200);
        }

        tr:hover {
            background: #f0f9ff;
        }

        .badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-warning { background: #fef3c7; color: #92400e; }

        .print-btn {
            position: fixed;
            bottom: 25px;
            right: 25px;
            background: var(--primary);
            color: white;
            padding: 1rem 2rem;
            border-radius: 50px;
            font-size: 1.1rem;
            box-shadow: 0 10px 25px rgba(37,99,235,0.4);
            cursor: pointer;
            z-index: 1000;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
        }

        .print-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 30px rgba(37,99,235,0.5);
        }

        @media print {
            body * { visibility: hidden; }
            .report-container, .report-container * { visibility: visible; }
            .report-container { position: absolute; left: 0; top: 0; width: 100%; box-shadow: none; border: none; }
            .print-btn, .main-content > *:not(.report-container) { display: none !important; }
        }

        .highlight {
            background: linear-gradient(120deg, #fef3c7, #fde68a);
            padding: 1rem;
            border-radius: 10px;
            border-left: 5px solid var(--warning);
            margin: 1.5rem 0;
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>

    <main class="main-content">
        <div class="report-container">
            <!-- Header -->
            <div class="report-header">
                <h1><i class="fas fa-hospital"></i> School Health Report</h1>
                <p>Complete Health Screening Summary • <?php echo date('F Y'); ?></p>
            </div>

            <!-- Key Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_students; ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $completed_screenings; ?></div>
                    <div class="stat-label">Screenings Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $normal_health; ?></div>
                    <div class="stat-label text-success"><i class="fas fa-check-circle"></i> Healthy</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number text-danger"><?php echo $referral_needed; ?></div>
                    <div class="stat-label"><i class="fas fa-exclamation-triangle"></i> Needs Referral</div>
                </div>
            </div>

            <div class="report-body">
                <!-- Alert if many referrals -->
                <?php if ($referral_needed > 10): ?>
                    <div class="highlight">
                        <strong>Attention Required:</strong> <?php echo $referral_needed; ?> students need medical follow-up. 
                        Consider organizing a parent meeting or health camp.
                    </div>
                <?php endif; ?>

                <!-- Grade-wise Summary -->
                <div class="section">
                    <h2 class="section-title"><i class="fas fa-chart-bar"></i> Grade-wise Health Status</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Grade</th>
                                <th>Total Students</th>
                                <th>Screened</th>
                                <th>Healthy</th>
                                <th>Needs Referral</th>
                                <th>% Affected</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_screened = 0;
                            $total_referral = 0;
                            foreach ($grade_stats as $g): 
                                $total_in_grade = $pdo->query("SELECT COUNT(*) FROM students WHERE grade = '{$g['grade']}'")->fetchColumn();
                                $screened = $g['screened'] ?? 0;
                                $referral = $g['needs_referral'] ?? 0;
                                $healthy = $screened - $referral;
                                $percent = $screened > 0 ? round(($referral / $screened) * 100, 1) : 0;
                                $total_screened += $screened;
                                $total_referral += $referral;
                            ?>
                                <tr>
                                    <td><strong>Grade <?php echo $g['grade']; ?></strong></td>
                                    <td><?php echo $total_in_grade; ?></td>
                                    <td><?php echo $screened; ?></td>
                                    <td class="text-success"><?php echo $healthy; ?></td>
                                    <td class="text-danger"><?php echo $referral; ?></td>
                                    <td>
                                        <?php if ($percent > 15): ?>
                                            <span class="badge badge-danger"><?php echo $percent; ?>%</span>
                                        <?php elseif ($percent > 5): ?>
                                            <span class="badge badge-warning"><?php echo $percent; ?>%</span>
                                        <?php else: ?>
                                            <span class="badge badge-success"><?php echo $percent; ?>%</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Recent Activity -->
                <div class="section">
                    <h2 class="section-title"><i class="fas fa-clock"></i> Recent Screenings</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Student</th>
                                <th>Grade</th>
                                <th>Type</th>
                                <th>Referral</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent as $r): ?>
                                <tr>
                                    <td><?php echo date('j M Y', strtotime($r['screening_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($r['student_name']); ?><br>
                                        <small><?php echo $r['student_code']; ?></small>
                                    </td>
                                    <td><?php echo $r['grade']; ?></td>
                                    <td><?php echo ucwords(str_replace('_', ' ', $r['screening_type'])); ?></td>
                                    <td>
                                        <span class="badge <?php echo $r['referral_needed'] ? 'badge-danger' : 'badge-success'; ?>">
                                            <?php echo $r['referral_needed'] ? 'Yes' : 'No'; ?>
                                        </span>
                                    </td>
                                    <td><span class="badge badge-info"><?php echo ucfirst($r['status']); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div style="text-align: center; padding: 2rem; color: var(--gray-600);">
                    <p><em>Report generated on <?php echo date('d F Y \a\t h:i A'); ?></em></p>
                </div>
            </div>
        </div>

        <!-- Floating Print Button -->
        <button onclick="window.print()" class="print-btn">
            <i class="fas fa-print"></i> Print / Save as PDF
        </button>
    </main>
</body>
</html>