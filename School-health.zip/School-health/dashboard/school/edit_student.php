<?php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session
$school_id = $_SESSION['school_id'] ?? 1;

// Get student ID from URL
$student_id = $_GET['id'] ?? null;

if (!$student_id) {
    header("Location: manage_students.php");
    exit;
}

// Fetch student data
try {
    $stmt = $pdo->prepare("
        SELECT s.*, u.full_name, u.email, u.phone 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        WHERE s.id = ? AND s.school_id = ?
    ");
    $stmt->execute([$student_id, $school_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        header("Location: manage_students.php");
        exit;
    }
} catch (PDOException $e) {
    die("Error fetching student data: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $student_code = $_POST['student_code'];
    $grade = $_POST['grade'];
    $date_of_birth = $_POST['date_of_birth'];
    
    // Validate and sanitize gender input
    $gender = $_POST['gender'] ?? '';
    $allowed_genders = ['Male', 'Female', 'Other'];
    if (!in_array($gender, $allowed_genders)) {
        $gender = ''; // Set to empty if not valid
    }
    
    $parent_name = $_POST['parent_name'] ?? '';
    $parent_phone = $_POST['parent_phone'] ?? '';
    $address = $_POST['address'] ?? '';

    try {
        $pdo->beginTransaction();
        
        // Update users table
        $user_stmt = $pdo->prepare("
            UPDATE users 
            SET full_name = ?, email = ?, phone = ? 
            WHERE id = ?
        ");
        $user_stmt->execute([$full_name, $email, $phone, $student['user_id']]);
        
        // Update students table - only existing columns
        $student_stmt = $pdo->prepare("
            UPDATE students 
            SET student_code = ?, grade = ?, date_of_birth = ?, gender = ?, 
                parent_name = ?, parent_phone = ?, address = ?
            WHERE id = ? AND school_id = ?
        ");
        $student_stmt->execute([
            $student_code, $grade, $date_of_birth, $gender,
            $parent_name, $parent_phone, $address,
            $student_id, $school_id
        ]);
        
        $pdo->commit();
        $_SESSION['message'] = "Student updated successfully!";
        $_SESSION['message_type'] = 'success';
        header("Location: manage_students.php");
        exit;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error_message = "Error updating student: " . $e->getMessage();
    }
}

// Safe value retrieval function
function getStudentValue($student, $key, $default = '') {
    return isset($student[$key]) ? htmlspecialchars($student[$key]) : $default;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student - School Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --dark-blue: #1e40af;
            --accent-blue: #60a5fa;
            --white: #ffffff;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --border-radius: 8px;
        }

        .main-content {
            margin-left: 280px;
            padding: 20px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
        }

        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 1.5rem;
        }

        .form-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--primary-light);
        }

        .form-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-header p {
            opacity: 0.9;
            font-size: 0.95rem;
            margin: 0;
        }

        .edit-form {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            border: 1px solid var(--gray-200);
        }

        .form-section {
            padding: 1.5rem;
            border-bottom: 1px solid var(--gray-100);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--primary-blue);
        }

        .section-header i {
            color: var(--primary-blue);
            font-size: 1.1rem;
        }

        .section-header h2 {
            color: var(--gray-800);
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.375rem;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
        }

        .form-control {
            width: 100%;
            padding: 0.625rem 0.875rem;
            border: 1.5px solid var(--gray-300);
            border-radius: 6px;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            background: var(--white);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
            background-position: right 0.5rem center;
            background-repeat: no-repeat;
            background-size: 1em 1em;
            padding-right: 2rem;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 80px;
        }

        .form-actions {
            display: flex;
            gap: 0.75rem;
            justify-content: flex-end;
            padding: 1.5rem;
            background: var(--gray-50);
            border-top: 1px solid var(--gray-200);
        }

        .btn {
            padding: 0.625rem 1.25rem;
            border: none;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
        }

        .btn-primary {
            background: var(--primary-blue);
            color: white;
            border: 1px solid var(--primary-dark);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--white);
            color: var(--gray-700);
            border: 1px solid var(--gray-300);
        }

        .btn-secondary:hover {
            background: var(--gray-100);
            border-color: var(--gray-400);
        }

        .required::after {
            content: " *";
            color: var(--danger);
        }

        .form-help {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 0.25rem;
        }

        .alert {
            padding: 0.875rem 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            border-left: 4px solid transparent;
            font-size: 0.875rem;
        }

        .alert-error {
            background: #fef2f2;
            border-color: var(--danger);
            color: #dc2626;
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 1rem;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_school.php'; ?>
    <?php include '../../components/navbar_school.php'; ?>
    
    <main class="main-content">
        <div class="form-container">
            <!-- Form Header -->
            <div class="form-header">
                <h1><i class="fas fa-user-edit"></i> Edit Student</h1>
                <p>Update student information and details</p>
            </div>

            <!-- Display Error Messages -->
            <?php if (isset($error_message)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Edit Form -->
            <form method="POST" class="edit-form">
                <!-- Personal Information -->
                <div class="form-section">
                    <div class="section-header">
                        <i class="fas fa-user"></i>
                        <h2>Personal Information</h2>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="full_name" class="form-label required">Full Name</label>
                            <input type="text" id="full_name" name="full_name" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'full_name'); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email" class="form-label required">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'email'); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'phone'); ?>">
                        </div>

                        <div class="form-group">
                            <label for="date_of_birth" class="form-label required">Date of Birth</label>
                            <input type="date" id="date_of_birth" name="date_of_birth" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'date_of_birth'); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="gender" class="form-label">Gender</label>
                            <select id="gender" name="gender" class="form-control">
                                <option value="">Select Gender</option>
                                <option value="Male" <?php echo getStudentValue($student, 'gender') == 'Male' ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo getStudentValue($student, 'gender') == 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo getStudentValue($student, 'gender') == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- School Information -->
                <div class="form-section">
                    <div class="section-header">
                        <i class="fas fa-graduation-cap"></i>
                        <h2>School Information</h2>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="student_code" class="form-label required">Student Code</label>
                            <input type="text" id="student_code" name="student_code" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'student_code'); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="grade" class="form-label required">Grade</label>
                            <select id="grade" name="grade" class="form-control" required>
                                <option value="">Select Grade</option>
                                <?php for ($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo getStudentValue($student, 'grade') == $i ? 'selected' : ''; ?>>
                                        Grade <?php echo $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Parent/Guardian Information -->
                <div class="form-section">
                    <div class="section-header">
                        <i class="fas fa-users"></i>
                        <h2>Parent/Guardian Information</h2>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="parent_name" class="form-label">Parent/Guardian Name</label>
                            <input type="text" id="parent_name" name="parent_name" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'parent_name'); ?>">
                        </div>

                        <div class="form-group">
                            <label for="parent_phone" class="form-label">Parent/Guardian Phone</label>
                            <input type="tel" id="parent_phone" name="parent_phone" class="form-control" 
                                   value="<?php echo getStudentValue($student, 'parent_phone'); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="address" class="form-label">Address</label>
                        <textarea id="address" name="address" class="form-control" 
                                  rows="3" placeholder="Enter full address..."><?php echo getStudentValue($student, 'address'); ?></textarea>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <a href="manage_students.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Students
                    </a>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Student
                    </button>
                </div>
            </form>
        </div>
    </main>

    <script src="../../components/scripts.js"></script>
</body>
</html>