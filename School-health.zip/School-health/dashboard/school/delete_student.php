<?php
// force_delete_student.php
require_once '../../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school') {
    header("Location: ../login.php");
    exit;
}

// Get school ID from session
$school_id = $_SESSION['school_id'] ?? 1;

// Get student ID from URL
$student_id = $_GET['id'] ?? null;

if (!$student_id) {
    $_SESSION['message'] = "No student ID provided.";
    $_SESSION['message_type'] = 'error';
    header("Location: manage_students.php");
    exit;
}

try {
    // First get the user_id to delete from users table
    $stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ? AND school_id = ?");
    $stmt->execute([$student_id, $school_id]);
    $student = $stmt->fetch();
    
    if ($student) {
        $pdo->beginTransaction();
        
        // 1. Delete from screening_schedule table
        $delete_schedule = $pdo->prepare("DELETE FROM screening_schedule WHERE student_id = ?");
        $delete_schedule->execute([$student_id]);
        
        // 2. Delete from screening_history table
        $delete_history = $pdo->prepare("DELETE FROM screening_history WHERE student_id = ?");
        $delete_history->execute([$student_id]);
        
        // 3. Delete from students table
        $delete_student = $pdo->prepare("DELETE FROM students WHERE id = ? AND school_id = ?");
        $delete_student->execute([$student_id, $school_id]);
        
        // 4. Delete from users table
        $delete_user = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $delete_user->execute([$student['user_id']]);
        
        $pdo->commit();
        
        $_SESSION['message'] = "Student and all related records permanently deleted successfully!";
        $_SESSION['message_type'] = 'success';
        
    } else {
        $_SESSION['message'] = "Student not found or you don't have permission to delete this student.";
        $_SESSION['message_type'] = 'error';
    }
} catch (PDOException $e) {
    $pdo->rollBack();
    $_SESSION['message'] = "Error deleting student: " . $e->getMessage();
    $_SESSION['message_type'] = 'error';
}

header("Location: manage_students.php");
exit;
?>