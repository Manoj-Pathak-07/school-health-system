<?php
require_once '../../config.php';

// Check authentication and role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../login.php");
    exit;
}

$doctor_id = $_SESSION['user_id'];

// Get filter parameters
$search = $_GET['search'] ?? '';
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$referral_filter = $_GET['referral'] ?? '';

// Build query with filters
$where_conditions = ["sh.doctor_id = ?"];
$params = [$doctor_id];

if (!empty($search)) {
    $where_conditions[] = "(u.full_name LIKE ? OR s.student_code LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($type_filter)) {
    $where_conditions[] = "sh.screening_type = ?";
    $params[] = $type_filter;
}

if (!empty($status_filter)) {
    $where_conditions[] = "sh.status = ?";
    $params[] = $status_filter;
}

if (!empty($date_from)) {
    $where_conditions[] = "sh.screening_date >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $where_conditions[] = "sh.screening_date <= ?";
    $params[] = $date_to;
}

if (!empty($referral_filter)) {
    if ($referral_filter === 'yes') {
        $where_conditions[] = "sh.referral_needed = 1";
    } elseif ($referral_filter === 'no') {
        $where_conditions[] = "sh.referral_needed = 0";
    }
}

$where_sql = implode(" AND ", $where_conditions);

// Get total count for pagination
$count_sql = "SELECT COUNT(*) FROM screening_history sh 
              JOIN students s ON sh.student_id = s.id 
              JOIN users u ON s.user_id = u.id 
              WHERE $where_sql";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_records = $count_stmt->fetchColumn();

// Pagination
$records_per_page = 8;
$total_pages = ceil($total_records / $records_per_page);
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($current_page - 1) * $records_per_page;

// Get screening records
$sql = "SELECT sh.*, 
               u.full_name as student_name, 
               s.student_code, 
               s.grade,
               dr.full_name as doctor_name
        FROM screening_history sh 
        JOIN students s ON sh.student_id = s.id 
        JOIN users u ON s.user_id = u.id 
        JOIN users dr ON sh.doctor_id = dr.id 
        WHERE $where_sql 
        ORDER BY sh.screening_date DESC, sh.created_at DESC 
        LIMIT $records_per_page OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$screening_records = $stmt->fetchAll();

// Get unique screening types for filter dropdown
$types_sql = "SELECT DISTINCT screening_type FROM screening_history WHERE doctor_id = ? ORDER BY screening_type";
$types_stmt = $pdo->prepare($types_sql);
$types_stmt->execute([$doctor_id]);
$screening_types = $types_stmt->fetchAll(PDO::FETCH_COLUMN);

// Get status counts for statistics
$status_counts_sql = "SELECT status, COUNT(*) as count FROM screening_history WHERE doctor_id = ? GROUP BY status";
$status_counts_stmt = $pdo->prepare($status_counts_sql);
$status_counts_stmt->execute([$doctor_id]);
$status_counts = $status_counts_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screening Records - Doctor Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --dark-blue: #1e40af;
            --accent-blue: #60a5fa;
            --white: #ffffff;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --border-radius: 6px;
        }

        .main-content {
            margin-left: 280px;
            padding: 15px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--primary-light);
        }

        .page-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .page-header p {
            opacity: 0.9;
            font-size: 0.95rem;
            margin: 0;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background: var(--white);
            padding: 1.25rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .stat-number {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary-blue);
            display: block;
            line-height: 1;
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--gray-600);
            font-weight: 500;
            margin-top: 0.5rem;
        }

        .filters-card {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            border: 1px solid var(--gray-200);
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-label {
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 0.375rem;
            font-size: 0.8rem;
        }

        .filter-control {
            padding: 0.5rem 0.75rem;
            border: 1.5px solid var(--gray-300);
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            background: var(--white);
            transition: all 0.2s ease;
        }

        .filter-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 0.5rem;
            align-items: flex-end;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
        }

        .btn-primary {
            background: var(--primary-blue);
            color: white;
            border: 1px solid var(--primary-dark);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: var(--white);
            color: var(--gray-700);
            border: 1px solid var(--gray-300);
        }

        .btn-secondary:hover {
            background: var(--gray-100);
            border-color: var(--gray-400);
        }

        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.8rem;
        }

        .records-card {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            border: 1px solid var(--gray-200);
        }

        .table-header {
            padding: 1.25rem;
            border-bottom: 1px solid var(--gray-200);
            background: var(--gray-50);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h3 {
            color: var(--gray-800);
            font-size: 1.1rem;
            font-weight: 600;
            margin: 0;
        }

        .records-table {
            width: 100%;
            border-collapse: collapse;
        }

        .records-table th {
            background: var(--gray-50);
            padding: 0.875rem;
            text-align: left;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid var(--gray-200);
        }

        .records-table td {
            padding: 0.875rem;
            border-bottom: 1px solid var(--gray-200);
            color: var(--gray-700);
            font-size: 0.85rem;
        }

        .records-table tr:hover {
            background: var(--gray-50);
        }

        .records-table tr:last-child td {
            border-bottom: none;
        }

        .status-badge {
            padding: 0.25rem 0.625rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .status-completed {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .status-scheduled {
            background: #dbeafe;
            color: #1e40af;
            border: 1px solid #bfdbfe;
        }

        .status-cancelled {
            background: #fecaca;
            color: #dc2626;
            border: 1px solid #fca5a5;
        }

        .type-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }

        .referral-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
            border: 1px solid transparent;
        }

        .referral-yes {
            background: #fef2f2;
            color: #dc2626;
            border-color: #fecaca;
        }

        .referral-no {
            background: #f0fdf4;
            color: #166534;
            border-color: #bbf7d0;
        }

        .recommendation-text {
            max-width: 180px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 0.8rem;
            color: var(--gray-600);
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.375rem;
            padding: 1.25rem;
            border-top: 1px solid var(--gray-200);
        }

        .pagination-btn {
            padding: 0.5rem 0.75rem;
            border: 1px solid var(--gray-300);
            border-radius: var(--border-radius);
            background: var(--white);
            color: var(--gray-700);
            text-decoration: none;
            font-size: 0.85rem;
            transition: all 0.2s ease;
        }

        .pagination-btn:hover {
            background: var(--gray-100);
            border-color: var(--gray-400);
        }

        .pagination-btn.active {
            background: var(--primary-blue);
            color: white;
            border-color: var(--primary-blue);
        }

        .pagination-btn.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .empty-state {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: var(--gray-500);
        }

        .empty-state i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .action-buttons {
            display: flex;
            gap: 0.375rem;
        }

        .vital-signs-compact {
            font-size: 0.8rem;
            color: var(--gray-600);
            line-height: 1.3;
        }

        @media (max-width: 768px) {
            .container {
                padding: 0.75rem;
            }

            .stats-cards {
                grid-template-columns: repeat(2, 1fr);
            }

            .filters-grid {
                grid-template-columns: 1fr;
            }

            .filter-actions {
                grid-column: 1;
            }

            .records-table {
                font-size: 0.8rem;
            }

            .records-table th,
            .records-table td {
                padding: 0.625rem;
            }

            .action-buttons {
                flex-direction: column;
            }

            .table-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
        }

        @media (max-width: 480px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Enhanced Sidebar & Navbar -->
    <?php include '../../components/sidebar_doctor.php'; ?>
    <?php include '../../components/navbar_doctor.php'; ?>
    
    <main class="main-content">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <h1><i class="fas fa-clipboard-list"></i> Screening Records</h1>
                <p>View and manage all student health screening records</p>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $total_records; ?></span>
                    <span class="stat-label">Total Records</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_counts['completed'] ?? 0; ?></span>
                    <span class="stat-label">Completed</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_counts['pending'] ?? 0; ?></span>
                    <span class="stat-label">Pending</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">
                        <?php 
                        $today_sql = "SELECT COUNT(*) FROM screening_history WHERE doctor_id = ? AND screening_date = CURDATE()";
                        $today_stmt = $pdo->prepare($today_sql);
                        $today_stmt->execute([$doctor_id]);
                        echo $today_stmt->fetchColumn();
                        ?>
                    </span>
                    <span class="stat-label">Today</span>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-card">
                <form method="GET" action="">
                    <div class="filters-grid">
                        <div class="filter-group">
                            <label class="filter-label">Search Student</label>
                            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                                   class="filter-control" placeholder="Name or student code...">
                        </div>

                        <div class="filter-group">
                            <label class="filter-label">Screening Type</label>
                            <select name="type" class="filter-control">
                                <option value="">All Types</option>
                                <?php foreach($screening_types as $type): ?>
                                    <option value="<?php echo htmlspecialchars($type); ?>" 
                                        <?php echo $type_filter === $type ? 'selected' : ''; ?>>
                                        <?php echo ucwords(str_replace('_', ' ', $type)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label class="filter-label">Status</label>
                            <select name="status" class="filter-control">
                                <option value="">All Status</option>
                                <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="scheduled" <?php echo $status_filter === 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label class="filter-label">Referral</label>
                            <select name="referral" class="filter-control">
                                <option value="">All</option>
                                <option value="yes" <?php echo $referral_filter === 'yes' ? 'selected' : ''; ?>>Yes</option>
                                <option value="no" <?php echo $referral_filter === 'no' ? 'selected' : ''; ?>>No</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label class="filter-label">Date From</label>
                            <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="filter-control">
                        </div>

                        <div class="filter-group">
                            <label class="filter-label">Date To</label>
                            <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="filter-control">
                        </div>

                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Apply
                            </button>
                            <a href="screening_records.php" class="btn btn-secondary">
                                <i class="fas fa-redo"></i> Clear
                            </a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Records Table -->
            <div class="records-card">
                <div class="table-header">
                    <h3>Screening Records (<?php echo $total_records; ?> found)</h3>
                    <a href="doctor_screening_form.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> New Screening
                    </a>
                </div>

                <?php if (!empty($screening_records)): ?>
                    <div style="overflow-x: auto;">
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Grade</th>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Vitals</th>
                                    <th>Recommendation</th>
                                    <th>Referral</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($screening_records as $record): ?>
                                    <tr>
                                        <td>
                                            <div style="font-weight: 600; font-size: 0.9rem;"><?php echo htmlspecialchars($record['student_name']); ?></div>
                                            <div style="font-size: 0.75rem; color: var(--gray-500);"><?php echo htmlspecialchars($record['student_code']); ?></div>
                                        </td>
                                        <td><?php echo htmlspecialchars($record['grade']); ?></td>
                                        <td style="white-space: nowrap;">
                                            <?php echo date('M j, Y', strtotime($record['screening_date'])); ?>
                                        </td>
                                        <td>
                                            <span class="type-badge">
                                                <?php echo ucwords(str_replace('_', ' ', $record['screening_type'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="vital-signs-compact">
                                                <?php if ($record['height']): ?><div>H: <?php echo $record['height']; ?>cm</div><?php endif; ?>
                                                <?php if ($record['weight']): ?><div>W: <?php echo $record['weight']; ?>kg</div><?php endif; ?>
                                                <?php if ($record['temperature']): ?><div>T: <?php echo $record['temperature']; ?>°C</div><?php endif; ?>
                                                <?php if (!$record['height'] && !$record['weight'] && !$record['temperature']): ?>
                                                    <span style="color: var(--gray-400);">No data</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if (!empty($record['recommendation'])): ?>
                                                <div class="recommendation-text" title="<?php echo htmlspecialchars($record['recommendation']); ?>">
                                                    <?php echo htmlspecialchars($record['recommendation']); ?>
                                                </div>
                                            <?php else: ?>
                                                <span style="color: var(--gray-400); font-size: 0.8rem;">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="referral-badge referral-<?php echo $record['referral_needed'] ? 'yes' : 'no'; ?>">
                                                <?php echo $record['referral_needed'] ? 'Yes' : 'No'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $record['status']; ?>">
                                                <?php echo ucfirst($record['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="view_screening.php?id=<?php echo $record['id']; ?>" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="edit_screening.php?id=<?php echo $record['id']; ?>" class="btn btn-secondary btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($current_page > 1): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" class="pagination-btn">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php else: ?>
                                <span class="pagination-btn disabled">
                                    <i class="fas fa-chevron-left"></i>
                                </span>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 1 && $i <= $current_page + 1)): ?>
                                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                                       class="pagination-btn <?php echo $i == $current_page ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php elseif ($i == $current_page - 2 || $i == $current_page + 2): ?>
                                    <span class="pagination-btn">...</span>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if ($current_page < $total_pages): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" class="pagination-btn">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php else: ?>
                                <span class="pagination-btn disabled">
                                    <i class="fas fa-chevron-right"></i>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-clipboard-list"></i>
                        <h3>No Screening Records Found</h3>
                        <p>No screening records match your current filters.</p>
                        <a href="doctor_screening_form.php" class="btn btn-primary" style="margin-top: 1rem;">
                            <i class="fas fa-plus"></i> Create First Screening
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="../../components/scripts.js"></script>
</body>
</html>