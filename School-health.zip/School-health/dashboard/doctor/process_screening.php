<?php

require_once '../../config.php';

// Check authentication and role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    $_SESSION['message'] = "Please login to access this page.";
    $_SESSION['message_type'] = 'error';
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get form data with proper sanitization
        $student_id = trim($_POST['student_id'] ?? '');
        $screening_date = trim($_POST['screening_date'] ?? '');
        $screening_type = trim($_POST['screening_type'] ?? '');
        $doctor_id = $_SESSION['user_id'];
        
        // Vital signs
        $height = !empty($_POST['height']) ? floatval($_POST['height']) : null;
        $weight = !empty($_POST['weight']) ? floatval($_POST['weight']) : null;
        $bmi = !empty($_POST['bmi']) ? floatval($_POST['bmi']) : null;
        $temperature = !empty($_POST['temperature']) ? floatval($_POST['temperature']) : null;
        $blood_pressure = trim($_POST['blood_pressure'] ?? '');
        $heart_rate = !empty($_POST['heart_rate']) ? intval($_POST['heart_rate']) : null;
        
        // General assessment
        $nutritional_status = trim($_POST['nutritional_status'] ?? '');
        $skin_conditions = isset($_POST['skin_conditions']) ? implode(', ', $_POST['skin_conditions']) : '';
        $hair_condition = trim($_POST['hair_condition'] ?? '');
        $vision_status = trim($_POST['vision'] ?? '');
        $general_findings = trim($_POST['general_findings'] ?? '');
        
        // Dental screening
        $oral_hygiene = trim($_POST['oral_hygiene'] ?? '');
        $dental_caries = trim($_POST['dental_caries'] ?? '');
        $gum_condition = trim($_POST['gum_condition'] ?? '');
        $dental_notes = trim($_POST['dental_notes'] ?? '');
        
        // Recommendations
        $recommendations = trim($_POST['recommendations'] ?? '');
        $referral_needed = trim($_POST['referral'] ?? '');
        $follow_up_date = !empty($_POST['follow_up_date']) ? trim($_POST['follow_up_date']) : null;

        // Validate required fields
        $errors = [];
        if (empty($student_id)) $errors[] = "Student selection is required";
        if (empty($screening_date)) $errors[] = "Screening date is required";
        if (empty($screening_type)) $errors[] = "Screening type is required";

        if (!empty($errors)) {
            throw new Exception(implode(", ", $errors));
        }

        // Check if screening_history table exists
        $table_check = $pdo->query("SHOW TABLES LIKE 'screening_history'");
        if ($table_check->rowCount() == 0) {
            throw new Exception("Database table not configured. Please contact administrator.");
        }

        // Insert screening record
        $sql = "INSERT INTO screening_history (
            student_id, doctor_id, screening_type, screening_date,
            height, weight, bmi, temperature, blood_pressure, heart_rate,
            nutritional_status, skin_conditions, hair_condition, vision_status,
            general_findings, oral_hygiene, dental_caries, gum_condition,
            dental_notes, recommendations, referral_needed, follow_up_date,
            status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed')";

        $stmt = $pdo->prepare($sql);
        
        $result = $stmt->execute([
            $student_id, $doctor_id, $screening_type, $screening_date,
            $height, $weight, $bmi, $temperature, $blood_pressure, $heart_rate,
            $nutritional_status, $skin_conditions, $hair_condition, $vision_status,
            $general_findings, $oral_hygiene, $dental_caries, $gum_condition,
            $dental_notes, $recommendations, $referral_needed, $follow_up_date
        ]);

        if ($result && $stmt->rowCount() > 0) {
            $_SESSION['message'] = "✅ Health screening record saved successfully!";
            $_SESSION['message_type'] = 'success';
        } else {
            throw new Exception("Failed to save screening record.");
        }

    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        $_SESSION['message'] = "❌ Database error: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    } catch (Exception $e) {
        $_SESSION['message'] = "❌ Error: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }

    header("Location: doctor_screening_form.php");
    exit;
} else {
    header("Location: doctor_screening_form.php");
    exit;
}
?>