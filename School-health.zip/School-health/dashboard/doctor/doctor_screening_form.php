<?php
require_once '../../config.php';

// Check authentication and role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../login.php");
    exit;
}

// Get doctor information
$doctor_id = $_SESSION['user_id'];

// Get students for dropdown - only those with scheduled screenings
try {
    $students_sql = "SELECT DISTINCT s.id, s.student_code, s.grade, u.full_name, ss.schedule_date
                     FROM students s 
                     JOIN users u ON s.user_id = u.id 
                     JOIN screening_schedule ss ON s.id = ss.student_id 
                     WHERE ss.doctor_id = ? 
                     AND ss.status = 'scheduled'
                     AND ss.schedule_date >= CURDATE()
                     ORDER BY ss.schedule_date ASC, u.full_name ASC";
    $students_stmt = $pdo->prepare($students_sql);
    $students_stmt->execute([$doctor_id]);
    $students = $students_stmt->fetchAll();
} catch (PDOException $e) {
    $students = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Screening Form - Doctor Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --dark-blue: #1e40af;
            --accent-blue: #60a5fa;
            --white: #ffffff;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --border-radius: 8px;
            --border-radius-lg: 12px;
        }

        .main-content {
            margin-left: 280px;
            padding: 20px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
        }

        .form-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 1.5rem;
        }

        .form-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--primary-light);
        }

        .form-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-header p {
            opacity: 0.9;
            font-size: 0.95rem;
            margin: 0;
        }

        .screening-form {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            border: 1px solid var(--gray-200);
        }

        .form-section {
            padding: 1.5rem;
            border-bottom: 1px solid var(--gray-100);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--primary-blue);
        }

        .section-header i {
            color: var(--primary-blue);
            font-size: 1.1rem;
        }

        .section-header h2 {
            color: var(--gray-800);
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.375rem;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
        }

        .form-control {
            width: 100%;
            padding: 0.625rem 0.875rem;
            border: 1.5px solid var(--gray-300);
            border-radius: 6px;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            background: var(--white);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
            background-position: right 0.5rem center;
            background-repeat: no-repeat;
            background-size: 1em 1em;
            padding-right: 2rem;
        }

        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-top: 0.375rem;
        }

        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }

        .checkbox-item input[type="checkbox"] {
            width: 16px;
            height: 16px;
            accent-color: var(--primary-blue);
        }

        .checkbox-item label {
            font-weight: 500;
            color: var(--gray-700);
            cursor: pointer;
            font-size: 0.875rem;
        }

        .radio-group {
            display: flex;
            gap: 1rem;
            margin-top: 0.375rem;
        }

        .radio-item {
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }

        .radio-item input[type="radio"] {
            width: 16px;
            height: 16px;
            accent-color: var(--primary-blue);
        }

        .radio-item label {
            font-weight: 500;
            color: var(--gray-700);
            cursor: pointer;
            font-size: 0.875rem;
        }

        .textarea-group {
            margin-bottom: 1rem;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 80px;
            line-height: 1.5;
            font-size: 0.875rem;
        }

        .vital-signs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 0.75rem;
            background: var(--gray-50);
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            border: 1px solid var(--gray-200);
        }

        .vital-sign {
            display: flex;
            flex-direction: column;
        }

        .vital-label {
            font-weight: 600;
            color: var(--gray-600);
            font-size: 0.8rem;
            margin-bottom: 0.25rem;
        }

        .vital-input {
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }

        .vital-input input {
            flex: 1;
            padding: 0.375rem;
            border: 1px solid var(--gray-300);
            border-radius: 4px;
            text-align: center;
            font-weight: 600;
            font-size: 0.875rem;
        }

        .vital-unit {
            color: var(--gray-500);
            font-size: 0.8rem;
            min-width: 25px;
        }

        .form-actions {
            display: flex;
            gap: 0.75rem;
            justify-content: flex-end;
            padding: 1.5rem;
            background: var(--gray-50);
            border-top: 1px solid var(--gray-200);
        }

        .btn {
            padding: 0.625rem 1.25rem;
            border: none;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
        }

        .btn-primary {
            background: var(--primary-blue);
            color: white;
            border: 1px solid var(--primary-dark);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--white);
            color: var(--gray-700);
            border: 1px solid var(--gray-300);
        }

        .btn-secondary:hover {
            background: var(--gray-100);
            border-color: var(--gray-400);
        }

        .required::after {
            content: " *";
            color: var(--danger);
        }

        .form-help {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 0.25rem;
        }

        .alert {
            padding: 0.875rem 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            border-left: 4px solid transparent;
            font-size: 0.875rem;
        }

        .alert-success {
            background: #f0fdf4;
            border-color: var(--success);
            color: #166534;
        }

        .alert-error {
            background: #fef2f2;
            border-color: var(--danger);
            color: #dc2626;
        }

        .alert-info {
            background: #dbeafe;
            border-color: var(--primary-blue);
            color: var(--dark-blue);
        }

        .compact-section {
            background: var(--gray-50);
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            border: 1px solid var(--gray-200);
        }

        .compact-section .section-header {
            margin-bottom: 0.75rem;
            border-bottom: 1px solid var(--gray-300);
            padding-bottom: 0.5rem;
        }

        .student-schedule-info {
            background: var(--primary-blue);
            color: white;
            padding: 0.75rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            font-size: 0.875rem;
        }

        .student-schedule-info i {
            margin-right: 0.5rem;
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 1rem;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .vital-signs-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .radio-group {
                flex-direction: column;
                gap: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .vital-signs-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Enhanced Sidebar & Navbar -->
    <?php include '../../components/sidebar_doctor.php'; ?>
    <?php include '../../components/navbar_doctor.php'; ?>
    
    <main class="main-content">
        <div class="form-container">
            <!-- Form Header -->
            <div class="form-header">
                <h1><i class="fas fa-stethoscope"></i> Health Screening Form</h1>
                <p>Complete health assessments for scheduled student appointments</p>
            </div>

            <!-- Display Messages -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type'] ?? 'success'; ?>">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Info Alert -->
            <?php if (empty($students)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>No Scheduled Appointments</strong> - You don't have any scheduled student screenings at the moment.
                </div>
            <?php endif; ?>

            <!-- Screening Form -->
            <form action="process_screening.php" method="POST" class="screening-form">
                <!-- Student Information Section -->
                <div class="compact-section">
                    <div class="section-header">
                        <i class="fas fa-user-graduate"></i>
                        <h2>Student Information</h2>
                    </div>
                    
                    <?php if (!empty($students)): ?>
                        <div class="student-schedule-info">
                            <i class="fas fa-calendar-check"></i>
                            <strong>Scheduled Students Only</strong> - Below are students with upcoming screening appointments
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="student_id" class="form-label required">Select Student</label>
                            <select id="student_id" name="student_id" class="form-control" required <?php echo empty($students) ? 'disabled' : ''; ?>>
                                <option value="">Choose a student...</option>
                                <?php foreach($students as $student): ?>
                                    <option value="<?php echo $student['id']; ?>" data-schedule-date="<?php echo $student['schedule_date']; ?>">
                                        <?php 
                                        echo htmlspecialchars($student['full_name'] . ' - ' . $student['student_code'] . ' (Grade ' . $student['grade'] . ')');
                                        echo ' - ' . date('M j, Y', strtotime($student['schedule_date']));
                                        ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (empty($students)): ?>
                                <div class="form-help" style="color: var(--warning);">
                                    <i class="fas fa-info-circle"></i> No students with scheduled screenings available.
                                </div>
                            <?php else: ?>
                                <div class="form-help">
                                    <i class="fas fa-info-circle"></i> Only students with scheduled appointments are shown
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="screening_date" class="form-label required">Screening Date</label>
                            <input type="date" id="screening_date" name="screening_date" class="form-control" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="screening_type" class="form-label required">Screening Type</label>
                            <select id="screening_type" name="screening_type" class="form-control" required>
                                <option value="">Select type...</option>
                                <option value="general">General Health Checkup</option>
                                <option value="dental">Dental Screening</option>
                                <option value="vision">Vision Screening</option>
                                <option value="ent">ENT Screening</option>
                                <option value="mental_health">Mental Health Assessment</option>
                                <option value="sports">Sports Physical</option>
                                <option value="annual">Annual Checkup</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Vital Signs Section -->
                <div class="compact-section">
                    <div class="section-header">
                        <i class="fas fa-heartbeat"></i>
                        <h2>Vital Signs</h2>
                    </div>
                    
                    <div class="vital-signs-grid">
                        <div class="vital-sign">
                            <span class="vital-label">Height (cm)</span>
                            <div class="vital-input">
                                <input type="number" name="height" step="0.1" min="50" max="250" placeholder="0.0">
                                <span class="vital-unit">cm</span>
                            </div>
                        </div>

                        <div class="vital-sign">
                            <span class="vital-label">Weight (kg)</span>
                            <div class="vital-input">
                                <input type="number" name="weight" step="0.1" min="10" max="200" placeholder="0.0">
                                <span class="vital-unit">kg</span>
                            </div>
                        </div>

                        <div class="vital-sign">
                            <span class="vital-label">BMI</span>
                            <div class="vital-input">
                                <input type="number" name="bmi" step="0.1" min="10" max="50" readonly placeholder="0.0">
                                <span class="vital-unit">kg/m²</span>
                            </div>
                        </div>

                        <div class="vital-sign">
                            <span class="vital-label">Temperature (°C)</span>
                            <div class="vital-input">
                                <input type="number" name="temperature" step="0.1" min="35" max="42" placeholder="0.0">
                                <span class="vital-unit">°C</span>
                            </div>
                        </div>

                        <div class="vital-sign">
                            <span class="vital-label">Blood Pressure</span>
                            <div class="vital-input">
                                <input type="text" name="blood_pressure" placeholder="120/80" maxlength="7">
                                <span class="vital-unit">mmHg</span>
                            </div>
                        </div>

                        <div class="vital-sign">
                            <span class="vital-label">Heart Rate</span>
                            <div class="vital-input">
                                <input type="number" name="heart_rate" min="40" max="200" placeholder="0">
                                <span class="vital-unit">bpm</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- General Health Assessment -->
                <div class="compact-section">
                    <div class="section-header">
                        <i class="fas fa-clipboard-check"></i>
                        <h2>General Health Assessment</h2>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">Nutritional Status</label>
                            <div class="radio-group">
                                <div class="radio-item">
                                    <input type="radio" id="nutrition_normal" name="nutritional_status" value="normal">
                                    <label for="nutrition_normal">Normal</label>
                                </div>
                                <div class="radio-item">
                                    <input type="radio" id="nutrition_underweight" name="nutritional_status" value="underweight">
                                    <label for="nutrition_underweight">Underweight</label>
                                </div>
                                <div class="radio-item">
                                    <input type="radio" id="nutrition_overweight" name="nutritional_status" value="overweight">
                                    <label for="nutrition_overweight">Overweight</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Skin Condition</label>
                            <div class="checkbox-group">
                                <div class="checkbox-item">
                                    <input type="checkbox" id="skin_normal" name="skin_conditions[]" value="normal">
                                    <label for="skin_normal">Normal</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="skin_eczema" name="skin_conditions[]" value="eczema">
                                    <label for="skin_eczema">Eczema</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="skin_fungal" name="skin_conditions[]" value="fungal">
                                    <label for="skin_fungal">Fungal</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" id="skin_rash" name="skin_conditions[]" value="rash">
                                    <label for="skin_rash">Rash</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Vision Screening</label>
                            <div class="radio-group">
                                <div class="radio-item">
                                    <input type="radio" id="vision_normal" name="vision" value="normal">
                                    <label for="vision_normal">Normal</label>
                                </div>
                                <div class="radio-item">
                                    <input type="radio" id="vision_refractive" name="vision" value="refractive_error">
                                    <label for="vision_refractive">Refractive Error</label>
                                </div>
                                <div class="radio-item">
                                    <input type="radio" id="vision_squint" name="vision" value="squint">
                                    <label for="vision_squint">Squint</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="general_findings" class="form-label">General Findings</label>
                        <textarea id="general_findings" name="general_findings" class="form-control" 
                                  placeholder="Record any general observations or findings..." rows="3"></textarea>
                    </div>
                </div>

                <!-- Recommendations & Follow-up -->
                <div class="compact-section">
                    <div class="section-header">
                        <i class="fas fa-file-medical-alt"></i>
                        <h2>Recommendations & Follow-up</h2>
                    </div>
                    
                    <div class="form-group">
                        <label for="recommendations" class="form-label">Medical Recommendations</label>
                        <textarea id="recommendations" name="recommendations" class="form-control" 
                                  placeholder="Provide medical recommendations, treatment plans, or follow-up instructions..." rows="3"></textarea>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="referral_needed" class="form-label">Referral Needed</label>
                            <select id="referral_needed" name="referral_needed" class="form-control">
                                <option value="0">No referral needed</option>
                                <option value="1">Referral required</option>
                            </select>
                        </div>

                        <div class="form-group" id="referral_type_group" style="display: none;">
                            <label for="referral_type" class="form-label">Referral Type</label>
                            <select id="referral_type" name="referral_type" class="form-control">
                                <option value="">Select type...</option>
                                <option value="dentist">Dentist</option>
                                <option value="ophthalmologist">Ophthalmologist</option>
                                <option value="ent_specialist">ENT Specialist</option>
                                <option value="dermatologist">Dermatologist</option>
                                <option value="pediatrician">Pediatrician</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="follow_up_date" class="form-label">Follow-up Date</label>
                            <input type="date" id="follow_up_date" name="follow_up_date" class="form-control">
                            <div class="form-help">Schedule follow-up if needed</div>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <a href="doctor_dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset Form
                    </button>
                    <button type="submit" class="btn btn-primary" <?php echo empty($students) ? 'disabled' : ''; ?>>
                        <i class="fas fa-save"></i> Save Screening Record
                    </button>
                </div>
            </form>
        </div>
    </main>

    <script src="../../components/scripts.js"></script>
    <script>
        // BMI Calculation
        document.addEventListener('DOMContentLoaded', function() {
            const heightInput = document.querySelector('input[name="height"]');
            const weightInput = document.querySelector('input[name="weight"]');
            const bmiInput = document.querySelector('input[name="bmi"]');
            const referralNeededSelect = document.getElementById('referral_needed');
            const referralTypeGroup = document.getElementById('referral_type_group');
            const studentSelect = document.getElementById('student_id');
            const screeningDateInput = document.getElementById('screening_date');

            function calculateBMI() {
                const height = parseFloat(heightInput.value) / 100;
                const weight = parseFloat(weightInput.value);

                if (height > 0 && weight > 0) {
                    const bmi = weight / (height * height);
                    bmiInput.value = bmi.toFixed(1);
                } else {
                    bmiInput.value = '';
                }
            }

            function toggleReferralType() {
                referralTypeGroup.style.display = referralNeededSelect.value === '1' ? 'block' : 'none';
            }

            // Auto-set screening date to student's scheduled date when selected
            studentSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                if (selectedOption.value && selectedOption.dataset.scheduleDate) {
                    screeningDateInput.value = selectedOption.dataset.scheduleDate;
                }
            });

            heightInput.addEventListener('input', calculateBMI);
            weightInput.addEventListener('input', calculateBMI);
            referralNeededSelect.addEventListener('change', toggleReferralType);

            // Initialize
            toggleReferralType();
        });
    </script>
</body>
</html>