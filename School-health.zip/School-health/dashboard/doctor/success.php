<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Success</title>
<style>
body { font-family: Arial, sans-serif; background-color:#f5f9ff; text-align:center; padding-top:50px; }
h1 { color:#0d6efd; }
</style>
</head>
<body>
<h1>✅ Screening Saved Successfully!</h1>
<p><a href="doctor_dashboard.php">Return to Dashboard</a></p>
</body>
</html>
