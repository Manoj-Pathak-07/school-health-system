const form = document.getElementById("screeningForm");
const nextBtn = document.getElementById("nextBtn");
const prevBtn = document.getElementById("prevBtn");
const submitBtn = document.getElementById("submitBtn");
const steps = document.querySelectorAll(".form-step");
const progress = document.getElementById("progress");
let currentStep = 0;

showStep(currentStep);

function showStep(n) {
    steps.forEach((step, i) => step.style.display = i === n ? "block" : "none");
    prevBtn.style.display = n === 0 ? "none" : "inline";
    nextBtn.style.display = n === steps.length - 1 ? "none" : "inline";
    submitBtn.style.display = n === steps.length - 1 ? "inline" : "none";
    progress.style.width = ((n+1)/steps.length)*100 + "%";
}

nextBtn.addEventListener("click", () => {
    if (!validateStep()) return;
    currentStep++;
    showStep(currentStep);
});

prevBtn.addEventListener("click", () => {
    currentStep--;
    showStep(currentStep);
});

function validateStep() {
    let valid = true;
    const inputs = steps[currentStep].querySelectorAll("input, select, textarea");
    inputs.forEach(input => {
        if (input.hasAttribute("required") && !input.value) {
            input.style.borderColor = "red";
            valid = false;
        } else {
            input.style.borderColor = "";
        }
    });
    return valid;
}
