<?php

require_once '../../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../login.php");
    exit;
}

// Get screening record ID
$screening_id = $_GET['id'] ?? 0;

// Fetch screening record details
try {
    $sql = "SELECT sh.*, 
                   u.full_name as student_name, 
                   s.student_code, 
                   s.grade,
                   dr.full_name as doctor_name
            FROM screening_history sh 
            JOIN students s ON sh.student_id = s.id 
            JOIN users u ON s.user_id = u.id 
            JOIN users dr ON sh.doctor_id = dr.id 
            WHERE sh.id = ? AND sh.doctor_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$screening_id, $_SESSION['user_id']]);
    $record = $stmt->fetch();
} catch (PDOException $e) {
    $record = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Screening - Doctor Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div style="max-width: 800px; margin: 2rem auto; padding: 0 1rem;">
        <a href="screening_records.php" style="display: inline-flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem; text-decoration: none;">
            <i class="fas fa-arrow-left"></i> Back to Records
        </a>
        
        <?php if ($record): ?>
            <h1>View Screening Record</h1>
            <p>Details for <?php echo htmlspecialchars($record['student_name']); ?></p>
            <!-- Add detailed view content here -->
        <?php else: ?>
            <h1>Record Not Found</h1>
            <p>The requested screening record was not found.</p>
        <?php endif; ?>
    </div>
</body>
</html>