<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: doctor_dashboard.php");
    exit;
}

$schedule_id = $_POST['schedule_id'];
$student_id = $_POST['student_id'];
$doctor_id = $_SESSION['user_id'];

// Begin transaction
$pdo->beginTransaction();

try {
    // Insert into screenings table
    $screening_sql = "INSERT INTO screenings (student_id, school_id, screening_date, height, weight, bmi, status, created_at)
                      SELECT student_id, school_id, NOW(), 0, 0, 0, 'Completed', NOW() FROM screening_schedule WHERE id=?";
    $stmt = $pdo->prepare($screening_sql);
    $stmt->execute([$schedule_id]);
    $screening_id = $pdo->lastInsertId();

    // Insert each detail table
    $stmt = $pdo->prepare("INSERT INTO screening_general (screening_id, nutrition_status, immunization_status, referral_needed) VALUES (?,?,?,?)");
    $stmt->execute([$screening_id, $_POST['nutrition_status'], $_POST['immunization_status'], $_POST['general_referral']]);

    $stmt = $pdo->prepare("INSERT INTO screening_dental (screening_id, oral_hygiene, referral_needed) VALUES (?,?,?)");
    $stmt->execute([$screening_id, $_POST['oral_hygiene'], $_POST['dental_referral']]);

    $stmt = $pdo->prepare("INSERT INTO screening_eye (screening_id, vision_right, vision_left, referral_needed) VALUES (?,?,?,?)");
    $stmt->execute([$screening_id, $_POST['vision_right'], $_POST['vision_left'], $_POST['eye_referral']]);

    $stmt = $pdo->prepare("INSERT INTO screening_ent (screening_id, ear_wax, referral_needed) VALUES (?,?,?)");
    $stmt->execute([$screening_id, $_POST['ear_wax'], $_POST['ent_referral']]);

    $stmt = $pdo->prepare("INSERT INTO screening_mental (screening_id, behavior, referral_needed) VALUES (?,?,?)");
    $stmt->execute([$screening_id, $_POST['mental_behavior'], $_POST['mental_referral']]);

    $stmt = $pdo->prepare("INSERT INTO screening_summary (screening_id, area_referred, urgency_level, remarks) VALUES (?,?,?,?)");
    $stmt->execute([$screening_id, $_POST['area_referred'], $_POST['urgency_level'], $_POST['remarks']]);

    // Update schedule status
    $stmt = $pdo->prepare("UPDATE screening_schedule SET status='completed' WHERE id=?");
    $stmt->execute([$schedule_id]);

    $pdo->commit();
    header("Location: success.php");
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die("Error saving screening: " . $e->getMessage());
}
?>
