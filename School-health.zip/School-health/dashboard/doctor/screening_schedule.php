<?php
require_once '../../config.php';

// Authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../../login.php");
    exit;
}

$doctor_id = $_SESSION['user_id'];

// Fetch upcoming schedules for this doctor with proper table joins
$stmt = $pdo->prepare("
    SELECT 
        ss.id,
        ss.schedule_date,
        ss.schedule_time,
        ss.screening_type,
        ss.status,
        ss.created_at,
        u.full_name as student_name,
        s.student_code,
        s.grade,
        s.date_of_birth
    FROM screening_schedule ss
    JOIN students s ON ss.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE ss.doctor_id = ? 
    AND ss.status = 'scheduled'
    ORDER BY ss.schedule_date ASC, ss.schedule_time ASC
");
$stmt->execute([$doctor_id]);
$schedules = $stmt->fetchAll();

// Get statistics
$total_scheduled = $pdo->prepare("SELECT COUNT(*) FROM screening_schedule WHERE doctor_id = ? AND status = 'scheduled'");
$total_scheduled->execute([$doctor_id]);
$total_scheduled_count = $total_scheduled->fetchColumn();

$today_scheduled = $pdo->prepare("SELECT COUNT(*) FROM screening_schedule WHERE doctor_id = ? AND schedule_date = CURDATE() AND status = 'scheduled'");
$today_scheduled->execute([$doctor_id]);
$today_scheduled_count = $today_scheduled->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Screening Schedule - School Health System</title>
    <link rel="stylesheet" href="../../components/styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .main-content {
            margin-left: 280px;
            padding: 20px;
            min-height: 100vh;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            color: white;
            padding: 2rem;
            border-radius: var(--border-radius-lg);
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
        }

        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
            text-align: center;
            border-left: 4px solid var(--primary-blue);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--gray-900);
            display: block;
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--gray-600);
            font-weight: 500;
        }

        .records-card {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
            overflow: hidden;
        }

        .table-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--gray-200);
            background: var(--gray-50);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h3 {
            color: var(--gray-800);
            font-size: 1.2rem;
            font-weight: 600;
        }

        .records-table {
            width: 100%;
            border-collapse: collapse;
        }

        .records-table th {
            background: var(--gray-50);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid var(--gray-200);
        }

        .records-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--gray-200);
            color: var(--gray-700);
            font-size: 0.9rem;
        }

        .records-table tr:hover {
            background: var(--gray-50);
        }

        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .status-scheduled {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-completed {
            background: #dcfce7;
            color: #166534;
        }

        .status-cancelled {
            background: #fecaca;
            color: #dc2626;
        }

        .type-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            background: var(--gray-100);
            color: var(--gray-700);
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--primary-blue);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--gray-700);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
        }

        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--gray-500);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }

            .stats-cards {
                grid-template-columns: 1fr;
            }

            .records-table {
                font-size: 0.8rem;
            }

            .action-buttons {
                flex-direction: column;
            }

            .table-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <?php include '../../components/sidebar_doctor.php'; ?>
    <div class="main-content">
        <?php include '../../components/navbar_doctor.php'; ?>

        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <h1><i class="fas fa-calendar-alt"></i> My Screening Schedule</h1>
                <p>Manage and view your upcoming student screening appointments</p>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $total_scheduled_count; ?></span>
                    <span class="stat-label">Total Scheduled</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?php echo $today_scheduled_count; ?></span>
                    <span class="stat-label">Today's Appointments</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">
                        <?php 
                        $upcoming_sql = "SELECT COUNT(*) FROM screening_schedule WHERE doctor_id = ? AND schedule_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND status = 'scheduled'";
                        $upcoming_stmt = $pdo->prepare($upcoming_sql);
                        $upcoming_stmt->execute([$doctor_id]);
                        echo $upcoming_stmt->fetchColumn();
                        ?>
                    </span>
                    <span class="stat-label">Next 7 Days</span>
                </div>
            </div>

            <!-- Schedule Table -->
            <div class="records-card">
                <div class="table-header">
                    <h3>Upcoming Screening Appointments (<?php echo count($schedules); ?> scheduled)</h3>
                </div>

                <?php if (!empty($schedules)): ?>
                    <div style="overflow-x: auto;">
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Grade</th>
                                    <th>Age</th>
                                    <th>Screening Date & Time</th>
                                    <th>Screening Type</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($schedules as $schedule): 
                                    $age = date_diff(date_create($schedule['date_of_birth']), date_create('today'))->y;
                                    $schedule_datetime = $schedule['schedule_date'] . ' ' . $schedule['schedule_time'];
                                    $is_today = $schedule['schedule_date'] == date('Y-m-d');
                                    $is_past = $schedule['schedule_date'] < date('Y-m-d');
                                ?>
                                    <tr>
                                        <td>
                                            <div style="font-weight: 600;"><?php echo htmlspecialchars($schedule['student_name']); ?></div>
                                            <div style="font-size: 0.8rem; color: var(--gray-500);"><?php echo htmlspecialchars($schedule['student_code']); ?></div>
                                        </td>
                                        <td><?php echo htmlspecialchars($schedule['grade']); ?></td>
                                        <td><?php echo $age; ?> years</td>
                                        <td>
                                            <div style="font-weight: 600; <?php echo $is_today ? 'color: var(--primary-blue);' : ''; ?>">
                                                <?php echo date('M j, Y', strtotime($schedule['schedule_date'])); ?>
                                            </div>
                                            <div style="font-size: 0.8rem; color: var(--gray-500);">
                                                <?php echo date('g:i A', strtotime($schedule['schedule_time'])); ?>
                                                <?php if ($is_today): ?>
                                                    <span style="color: var(--primary-blue); font-weight: 600;">• Today</span>
                                                <?php elseif ($is_past): ?>
                                                    <span style="color: var(--danger);">• Past</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="type-badge">
                                                <?php echo ucfirst(str_replace('_', ' ', $schedule['screening_type'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $schedule['status']; ?>">
                                                <?php echo ucfirst($schedule['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="doctor_screening_form.php?schedule_id=<?php echo $schedule['id']; ?>" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-clipboard-check"></i> Start Screening
                                                </a>
                                                <a href="cancel_schedule.php?id=<?php echo $schedule['id']; ?>" class="btn btn-danger btn-sm" 
                                                   onclick="return confirm('Are you sure you want to cancel this appointment?')">
                                                    <i class="fas fa-times"></i> Cancel
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <h3>No Upcoming Appointments</h3>
                        <p>You don't have any scheduled screening appointments at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="../../components/scripts.js"></script>
</body>
</html>