<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - School Health System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../../components/styles.css" rel="stylesheet">
</head>
<body>
    <!-- Enhanced Sidebar & Navbar -->
    <?php include '../../components/sidebar_doctor.php'; ?>
    <?php include '../../components/navbar_doctor.php'; ?>
    
    <main class="main-content">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            <!-- Welcome Card -->
            <div style="background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue)); 
                       color: white; padding: 30px; border-radius: 15px; margin-bottom: 30px;
                       box-shadow: 0 10px 30px rgba(37, 99, 235, 0.3);">
                <h1 style="margin: 0 0 10px 0; font-size: 2.5rem;">👨‍⚕️ Welcome, Dr. <?php echo $_SESSION['full_name']; ?>!</h1>
                <p style="margin: 0; opacity: 0.9; font-size: 1.1rem;">Ready to make a difference in student health today</p>
            </div>
            
            <!-- Quick Stats -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
                    <i class="fas fa-users" style="font-size: 2rem; color: var(--primary-blue); margin-bottom: 10px;"></i>
                    <h3 style="color: var(--primary-blue); margin: 10px 0;">15</h3>
                    <p style="color: var(--gray-600);">Students Today</p>
                </div>
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
                    <i class="fas fa-clipboard-check" style="font-size: 2rem; color: #10b981; margin-bottom: 10px;"></i>
                    <h3 style="color: #10b981; margin: 10px 0;">8</h3>
                    <p style="color: var(--gray-600);">Completed</p>
                </div>
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
                    <i class="fas fa-clock" style="font-size: 2rem; color: #f59e0b; margin-bottom: 10px;"></i>
                    <h3 style="color: #f59e0b; margin: 10px 0;">7</h3>
                    <p style="color: var(--gray-600);">Pending</p>
                </div>
            </div>
        </div>
    </main>
    
    <script src="../../components/scripts.js"></script>
</body>
</html>