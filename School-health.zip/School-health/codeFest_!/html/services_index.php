<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - School Health Screening</title>
    <link rel="stylesheet" href="/services_styles.css">
    <!-- font awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8fbff;
        }
        
        nav {
            background: linear-gradient(135deg, #003087, #0055ff);
            padding: 18px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 50, 120, 0.3);
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            /* Smooth scroll on mobile */
            scrollbar-width: none;
            /* Hide scrollbar Firefox */
        }
        
        nav::-webkit-scrollbar {
            display: none;
        }
        /* Hide scrollbar Chrome/Safari */
        
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            flex-shrink: 0;
        }
        
        .shield {
            width: 62px;
            height: 68px;
            flex-shrink: 0;
        }
        
        .logo-text {
            color: white;
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -1.4px;
            white-space: nowrap;
        }
        
        .logo-text span {
            color: #a8d8ff;
        }
        
        .tagline {
            color: #cce5ff;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        /* Menu – Always visible, white text, single line */
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 40px;
            flex-shrink: 0;
            white-space: nowrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 17px;
            position: relative;
            transition: all 0.3s;
        }
        
        .nav-links a:hover {
            color: #e0f2ff;
        }
        
        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 3px;
            bottom: -8px;
            left: 50%;
            background: white;
            border-radius: 3px;
            transition: width 0.4s;
            transform: translateX(-50%);
        }
        
        .nav-links a:hover::after {
            width: 100%;
        }
        /* Login Button */
        
        .login-btn {
            background: white;
            color: #003087 !important;
            padding: 12px 32px;
            border-radius: 50px;
            font-weight: 700;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
            transition: all 0.3s;
            flex-shrink: 0;
        }
        
        .login-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.35);
        }
        /* Extra small screens – still no hamburger, just horizontal scroll */
        
        @media (max-width: 480px) {
            nav {
                padding: 16px 4%;
                gap: 20px;
            }
            .nav-links {
                gap: 25px;
            }
            .nav-links a {
                font-size: 16px;
            }
            .login-btn {
                padding: 10px 24px;
                font-size: 15px;
            }
        }
    </style>
</head>

<body>
    <!-- Nav Section -->
    <!-- Navbar -->
    <nav>
        <!-- Logo -->
        <a href="#" class="logo">
            <div class="shield">
                <svg viewBox="0 0 100 110" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 8 L90 30 L90 62 C90 90 70 105 50 105 C30 105 10 90 10 62 L10 30 Z" fill="white"/>
          <path d="M50 16 L82 34 L82 58 C82 80 67 94 50 94 C33 94 18 80 18 58 L18 34 Z" fill="#0055ff"/>
          <circle cx="50" cy="36" r="10" fill="white"/>
          <rect x="42" y="46" width="16" height="32" rx="8" fill="white"/>
          <rect x="44" y="76" width="6" height="16" fill="white"/>
          <rect x="50" y="76" width="6" height="16" fill="white"/>
          <rect x="36" y="50" width="28" height="24" rx="6" fill="#a8d8ff"/>
          <rect x="40" y="74" width="20" height="8" rx="3" fill="white"/>
          <rect x="42" y="50" width="4" height="20" fill="white"/>
          <rect x="54" y="50" width="4" height="20" fill="white"/>
        </svg>
            </div>
            <div>
                <div class="logo-text">Student<span>Shield</span></div>
                <div class="tagline">School Health Guardian</div>
            </div>
        </a>

        <!-- Menu & Login – always visible -->
        <div class="nav-links">
            <a href="/html/index.html">Home</a>
            <a href="/html/services_index.html">Services</a>
            <a href="about_index.html">About</a>
            <div class="login_buttons">
                <i class="fa-solid fa-user"></i>
                <input type="submit" value="Login">
            </div>
        </div>
    </nav>
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero_image_section">
            <img src="../images/services_hero_image.jpeg" alt="Hero Section Image" style="opacity: 0.7;" ;>
            <h2>Our Core Services</h1>
        </div>

    </section>

    <!-- Core Services Section -->
    <section class=" services ">
        <div class="container ">
            <!-- <h2 class="section-title ">Our Core Services</h2> -->
            <div class="services-grid ">
                <div class="service-card ">
                    <h3>Student Health Checkups</h3>
                    <p>Comprehensive health screenings with detailed medical assessments. All health records are digitized and instantly accessible through secure personal portals.</p>
                </div>
                <div class="service-card ">
                    <h3>Teacher & Staff Health Assessments</h3>
                    <p>Complete health evaluations for school personnel ensuring a healthy teaching environment. Easy access to medical reports and health history.</p>
                </div>
                <div class="service-card ">
                    <h3>Digital Health Records</h3>
                    <p>Secure online access to all medical reports and health history. Individual login portals ensure privacy and data security for every user.</p>
                </div>
                <div class="service-card ">
                    <h3>School Health Management</h3>
                    <p>Streamlined student and staff enrollment system. Administrators can easily manage health profiles and track screening schedules.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="process ">
        <div class="container ">
            <h2 class="section-title ">How It Works</h2>
            <div class="process-steps ">
                <div class="step ">
                    <div class="step-number ">1</div>
                    <h3>School Registration</h3>
                    <p>School administrators register students and teachers in our system with basic information.</p>
                </div>
                <div class="step ">
                    <div class="step-number ">2</div>
                    <h3>Health Checkup</h3>
                    <p>Qualified doctors conduct thorough health screenings at your school or our facility.</p>
                </div>
                <div class="step ">
                    <div class="step-number ">3</div>
                    <h3>Report Submission</h3>
                    <p>Medical reports are digitally submitted through our secure system immediately after checkup.</p>
                </div>
                <div class="step ">
                    <div class="step-number ">4</div>
                    <h3>Instant Access</h3>
                    <p>Students, teachers, and staff access their personal health reports via individual secure login.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Key Features Section -->
    <section class="features ">
        <div class="container ">
            <h2 class="section-title ">Key Features & Benefits</h2>
            <div class="features-grid ">
                <div class="feature-item ">
                    <h4>Secure Individual Login Portals</h4>
                    <p>Every user has their own protected account with encrypted data.</p>
                </div>
                <div class="feature-item ">
                    <h4>Instant Report Access</h4>
                    <p>View medical reports immediately after doctor submission.</p>
                </div>
                <div class="feature-item ">
                    <h4>Digital Record Keeping</h4>
                    <p>No more lost papers - all records stored safely online.</p>
                </div>
                <div class="feature-item ">
                    <h4>Regular Health Monitoring</h4>
                    <p>Track health trends and maintain complete medical history.</p>
                </div>
                <div class="feature-item ">
                    <h4>Easy School Administration</h4>
                    <p>Simple dashboard for managing all student and staff profiles.</p>
                </div>
                <div class="feature-item ">
                    <h4>Mobile Friendly</h4>
                    <p>Access reports anytime, anywhere from any device.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Who We Serve Section -->
    <section class="audience ">
        <div class="container ">
            <h2 class="section-title ">Who We Serve</h2>
            <div class="audience-grid ">
                <div class="audience-card ">
                    <h3>Students</h3>
                    <p>Regular health checkups with easy access to medical reports and health history through personal secure accounts.</p>
                </div>
                <div class="audience-card ">
                    <h3>Teachers & Staff</h3>
                    <p>Comprehensive health assessments designed for school personnel with private access to all medical records.</p>
                </div>
                <div class="audience-card ">
                    <h3>School Administrators</h3>
                    <p>Efficient health management tools to oversee student and staff wellness programs with complete tracking systems.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- footer -->
    <footer>
        <div class="container ">
            <div class="footer-content ">
                <div class="footer-column ">
                    <div class="footer-logo ">
                        <i class="fas fa-stethoscope "></i> School Health Screening
                    </div>
                    <p>Transforming school health management through innovative technology solutions that prioritize student wellness and academic success.</p>
                </div>


                <div class="footer-column ">
                    <h3>Contact Us</h3>
                    <ul class="footer-links ">
                        <li><i class="fas fa-map-marker-alt "></i> Kuleshwor 14,Kathmandu Nepal</li>
                        <li><i class="fas fa-phone "></i> +977012548354</li>
                        <li><i class="fas fa-envelope "></i> jmc123@gmail.com</li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom ">
                <p>&copy; 2023 School Health Screening System. All rights reserved.</p>
            </div>
        </div>
    </footer>

</body>

</html>
</body>

</html>