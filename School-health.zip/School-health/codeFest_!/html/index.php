<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Health Check | Check Your Health For Free On JMC</title>
    <link rel="stylesheet" href="../css/styles.css">
    <!-- font awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />

 
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- navbar css -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8fbff;
        }
        
        nav {
            background: linear-gradient(135deg, #003087, #0055ff);
            padding: 18px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 50, 120, 0.3);
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            /* Smooth scroll on mobile */
            scrollbar-width: none;
            /* Hide scrollbar Firefox */
        }
        
        nav::-webkit-scrollbar {
            display: none;
        }
        /* Hide scrollbar Chrome/Safari */
        
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            flex-shrink: 0;
        }
        
        .shield {
            width: 62px;
            height: 68px;
            flex-shrink: 0;
        }
        
        .logo-text {
            color: white;
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -1.4px;
            white-space: nowrap;
        }
        
        .logo-text span {
            color: #a8d8ff;
        }
        
        .tagline {
            color: #cce5ff;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        /* Menu – Always visible, white text, single line */
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 40px;
            flex-shrink: 0;
            white-space: nowrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 17px;
            position: relative;
            transition: all 0.3s;
        }
        
        .nav-links a:hover {
            color: #e0f2ff;
        }
        
        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 3px;
            bottom: -8px;
            left: 50%;
            background: white;
            border-radius: 3px;
            transition: width 0.4s;
            transform: translateX(-50%);
        }
        
        .nav-links a:hover::after {
            width: 100%;
        }
        /* Login Button */
        
        .login-btn {
            background: white;
            color: #003087 !important;
            padding: 12px 32px;
            border-radius: 50px;
            font-weight: 700;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
            transition: all 0.3s;
            flex-shrink: 0;
        }
        
        .login-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.35);
        }
        /* Extra small screens – still no hamburger, just horizontal scroll */
        
        @media (max-width: 480px) {
            nav {
                padding: 16px 4%;
                gap: 20px;
            }
            .nav-links {
                gap: 25px;
            }
            .nav-links a {
                font-size: 16px;
            }
            .login-btn {
                padding: 10px 24px;
                font-size: 15px;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav>
        <!-- Logo -->
        <a href="index.html" class="logo">
            <div class="shield">
                <svg viewBox="0 0 100 110" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 8 L90 30 L90 62 C90 90 70 105 50 105 C30 105 10 90 10 62 L10 30 Z" fill="white"/>
          <path d="M50 16 L82 34 L82 58 C82 80 67 94 50 94 C33 94 18 80 18 58 L18 34 Z" fill="#0055ff"/>
          <circle cx="50" cy="36" r="10" fill="white"/>
          <rect x="42" y="46" width="16" height="32" rx="8" fill="white"/>
          <rect x="44" y="76" width="6" height="16" fill="white"/>
          <rect x="50" y="76" width="6" height="16" fill="white"/>
          <rect x="36" y="50" width="28" height="24" rx="6" fill="#a8d8ff"/>
          <rect x="40" y="74" width="20" height="8" rx="3" fill="white"/>
          <rect x="42" y="50" width="4" height="20" fill="white"/>
          <rect x="54" y="50" width="4" height="20" fill="white"/>
        </svg>
            </div>
            <div>
                <div class="logo-text">Student<span>Shield</span></div>
                <div class="tagline">School Health Guardian</div>
            </div>
        </a>

        <!-- Menu & Login – always visible -->
        <div class="nav-links">
            <a href="index.html">Home</a>
            <a href="services_index.html">Services</a>
            <a href="about_index.html">About</a>
            <div class="login_buttons">
           <a href="login.php"> <i class="fa-solid fa-user"></i></a></button>
                
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="section" id="section">
        <div class="hero_image_section">
            <img src="../images/hero_image.jpeg" alt="Hero Section Image" style="opacity: 0.9;">
            <h2>Ensuring<br> Health 🩺,<br> Empowering<br> Mind</h2>
        </div>

        <!-- About -->
        <div style="padding: 0.2rem 0 ;">
            <span style="display: flex;flex-direction:column; justify-content: center;align-items: center; margin-top: 4rem;">
                <h2
                    style="text-align: center; font-size: 3rem; margin-top: 2rem;text-shadow: 1px 1px 1px rgba(0,0,0,0.3);">
                    About Our Health Desk</h2>
                <hr style="width: 30rem;font-weight: 600;border: 2px solid ;box-shadow:1px 1px 1px rgba(0,0,0,0.3);">
            </span>
            <p style="font-size: 1.82rem;padding: 2.5rem 2.5rem 0 2.5rem;">We’re committed to supporting student wellness at Janamaitri Multiple Campus. Below are key details to help you access care and emergency support when you need it:</p>
            <div class="services_content">
                <!-- card1 -->
                <div class="card">
                    <span class="logo_heading">
                        <i class="fa-solid fa-clock" style="color: #1a3d7c;"></i>
                        <h2>Working Hours</h2>
                    </span>
                    <span style="display: flex; gap: 6rem;">
                        <p>Sunday to Friday:</p>
                        <p>6:00 AM – 12:00 PM </p>
                    </span>
                    <hr>
                    <p style="text-align: center;">We are open during these days and hours.</p>
                </div>
                <!-- card2 -->
                <div class="card">
                    <span class="logo_heading">
                        <i class="fa-solid fa-stethoscope" style="color: #3f8efc;"></i>
                        <h2>Dr. Sita</h2>
                    </span>
                    <span style="display: flex; gap: 6rem;">
                        <p>Sunday - Friday:</p>
                        <p>6:00 am - 12:00 pm </p>
                    </span>
                    <hr>
                    <p style="text-align: center;">Available during college hours at JMC</p>
                </div>
                <!-- card3 -->
                <div class="card">
                    <span class="logo_heading">
                        <i class="fa-solid fa-phone" style="color: red;"></i>
                        <h2>In Case of Emergency</h2>
                    </span>
                    <span style="display: flex;gap:4rem;">
                        <p>+977-9876543210</p>
                        <p>064-420123</p>
                    </span>
                    <hr>
                    <p style="text-align: center;">You can reach us anytime during an emergency.</p>
                </div>
            </div>
        </div>
        <!-- Services -->
        <div style="padding: 0.2rem 0" id="hero_section">
            <span style="display: flex;flex-direction:column; justify-content: center;align-items: center;">
                <h2
                    style="text-align: center; font-size: 3rem; margin-top: 2rem;text-shadow: 1px 1px 1px rgba(0,0,0,0.3);">
                    Services We Provide</h2>
                <hr style="width: 40rem;font-weight: 600;border: 2px solid ;box-shadow:1px 1px 1px rgba(0,0,0,0.3);">
            </span>
            <p style="font-size: 1.82rem;padding: 2.5rem 2.5rem 0 2.5rem;">Our health desk provides key medical services including general checkups, first aid, vaccinations, and mental health support. These services are available during clinic hours for all students and staff:</p>
            <div class="services_content">
                <!-- card -->
                <div class="card" style="height: 25rem; width: 16rem;">
                    <span class="logo_heading">
                        <img src="../images/checkup.png" alt="First Aid Image">
                        <h2>General<br>Health Checkups</h2>
                    </span>
                    <hr>
                    <p style="text-align: center;">Routine physical exams and basic health screenings.</p>
                </div>
                <!-- card -->
                <div class="card" style="height: 25rem; width: 16rem;">
                    <span class="logo_heading">
                        <img src="../images/awareness.png" alt="Awareness Image">
                        <h2>Health<br>Awareness Campaign</h2>
                    </span>
                    <hr>
                    <p style="text-align: center;">Posters, talks, and events to promote mental health.</p>
                </div>
                <!-- card -->
                <div class="card" style="height: 25rem; width: 16rem;">
                    <span class="logo_heading">
                        <img src="../images/first_aid.png" alt="First Aid Image">
                        <h2>First Aid &<br>Injury Core</h2>
                    </span>
                    <hr style="margin-top: 2.7rem;">
                    <p style="text-align: center;">Treatment for minor wounds, sprains, and accidents.</p>
                </div>
                <!-- card-->
                <div class="card" style="height: 25rem; width: 16rem;">
                    <span class="logo_heading">
                        <img src="../images/mental_health.png" alt="Mental Health Logo">
                        <h2>Metal Health Counseling</h2>
                    </span>
                    <hr style="margin-top: 2.7rem;">
                    <p style="text-align: center;">Support for stress, anxiety, and emotional well-being.</p>
                </div>
                <!-- card -->
                <div class="card" style="height: 25rem; width: 16rem;">
                    <span class="logo_heading">
                        <img src="../images/vaccination.png" alt="Vaccination Logo">
                        <h2>In Case of Emergency</h2>
                    </span>
                    <hr style="margin-top: 2.7rem;">
                    <p style="text-align: center;">Immunizations and on-site vaccine clinics available during emergencies.</p>
                </div>
            </div>
        </div>

        </div>

        <!-- FAQ Section -->

        <section class="faq-wrapper" id="faq">
            <div class="faq-container">
                <h2 class="faq-title">Frequently Asked Questions (FAQs)</h2>


                <div class="faq-item">
                    <button class="faq-question">Who can use the health desk services? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>All students, faculty, and staff of Janamaitri Multiple Campus are welcome to use our services during clinic hours.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">Do I need to book an appointment? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>No appointment is necessary for general checkups or first aid. For mental health counseling, we recommend booking in advance at the reception desk.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">Is there any cost for the services? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>All services provided by the health desk are free of charge for registered students and staff.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">What should I do in case of an emergency? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>Call our emergency contact numbers immediately: 977-9876543210 or 044-403123. You can also visit the health desk directly during working hours.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">Is my health information kept confidential? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>Yes, all consultations and records are handled with strict confidentiality in accordance with campus policy.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">Can I get vaccinated at the health desk? <span class="arrow">&#9662;</span></button>
                    <div class="faq-answer">
                        <p>Yes, we offer immunizations and vaccine clinics during scheduled health campaigns. Watch for announcements on campus notice boards.</p>
                    </div>
                </div>

            </div>
        </section>


        <!-- Alert and Announcement Section -->
        <section class="announcements-section">
            <div class="announcements-container">
                <h2 class="announcements-title">Announcements & Alerts</h2>

                <div class="announcement-item alert">
                    <strong>Upcoming Health Checkup:</strong>
                    <p>The next health checkup for students and staff will be held on <strong>Dec 5, 2025</strong> at the campus clinic from <strong>10:00 AM to 4:00 PM</strong>. Please register in advance at the reception desk.</p>
                </div>

                <div class="announcement-item info">
                    <strong>COVID-19 Vaccination Reminder:</strong>
                    <p>Vaccine doses will be available during the health campaign. Bring your vaccination card if applicable.</p>
                </div>

                <div class="announcement-item info">
                    <strong>Health Desk Timings:</strong>
                    <p>Clinic hours are Monday to Friday, 9:00 AM – 5:00 PM.</p>
                </div>
            </div>
        </section>


        <!-- Location and Map -->
        <section class="location-section">
            <div class="location-container">
                <h2 class="location-title">Our Location</h2>

                <!-- Static image of campus location -->
                <div style="display: flex; justify-self: space-around;gap: 4rem;">

                    <div class="campus-image-wrapper">
                        <img src="https://www.collegenp.com/uploads/2025/08/janamaitri-multiple-campus-building.png" alt="Janamaitri Multiple Campus, Kathmandu" class="campus-image">
                    </div>

                    <div class="location-info" style="  margin-top: 8rem;">
                        <p><strong>Address:</strong> Kuleshwor, Kathmandu, Nepal</p>
                        <p><strong>GPS Coordinates:</strong> 27.67376, 85.28103</p>
                        <p><strong>How to reach:</strong> Easily accessible from various parts of Kathmandu valley via local transport or private vehicles.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Footer -->
        <footer>
            <div class="container">
                <div class="footer-content">
                    <div class="footer-column">
                        <div class="footer-logo">
                            <i class="fas fa-stethoscope"></i> School Health Screening
                        </div>
                        <p style="color: white;">Transforming school health management through innovative technology solutions that prioritize student wellness and academic success.</p>
                    </div>


                    <div class="footer-column">
                        <h3>Contact Us</h3>
                        <ul class="footer-links">
                            <li><i class="fas fa-map-marker-alt"></i> Kuleshwor 14,Kathmandu Nepal</li>
                            <li><i class="fas fa-phone"></i> +977012548354</li>
                            <li><i class="fas fa-envelope"></i> jmc123@gmail.com</li>
                        </ul>
                    </div>
                </div>

                <div class="footer-bottom">
                    <p style="color: white;">&copy; 2023 School Health Screening System. All rights reserved.</p>
                </div>
            </div>
        </footer>

    </section>


    <script src="../js/script.js "></script>
</body>

</html>

</html>