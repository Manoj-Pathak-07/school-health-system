<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudentShield</title>
    <link rel="stylesheet" href="/about_styles.css">
    <link rel="stylesheet" href="/main_styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8fbff;
        }
        
        nav {
            background: linear-gradient(135deg, #003087, #0055ff);
            padding: 18px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 50, 120, 0.3);
            flex-wrap: nowrap;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            /* Smooth scroll on mobile */
            scrollbar-width: none;
            /* Hide scrollbar Firefox */
        }
        
        nav::-webkit-scrollbar {
            display: none;
        }
        /* Hide scrollbar Chrome/Safari */
        
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            flex-shrink: 0;
        }
        
        .shield {
            width: 62px;
            height: 68px;
            flex-shrink: 0;
        }
        
        .logo-text {
            color: white;
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -1.4px;
            white-space: nowrap;
        }
        
        .logo-text span {
            color: #a8d8ff;
        }
        
        .tagline {
            color: #cce5ff;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            white-space: nowrap;
        }
        /* Menu – Always visible, white text, single line */
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 40px;
            flex-shrink: 0;
            white-space: nowrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 17px;
            position: relative;
        }
        /* Login Button */
        /* Extra small screens – still no hamburger, just horizontal scroll */
        
        @media (max-width: 480px) {
            nav {
                padding: 16px 4%;
                gap: 20px;
            }
            .nav-links {
                gap: 25px;
            }
            .nav-links a {
                font-size: 16px;
            }
            .login-btn {
                padding: 10px 24px;
                font-size: 15px;
            }
        }
    </style>
</head>

<body>

    <nav>
        <!-- Logo -->
        <a href="#" class="logo">
            <div class="shield">
                <svg viewBox="0 0 100 110" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 8 L90 30 L90 62 C90 90 70 105 50 105 C30 105 10 90 10 62 L10 30 Z" fill="white"/>
          <path d="M50 16 L82 34 L82 58 C82 80 67 94 50 94 C33 94 18 80 18 58 L18 34 Z" fill="#0055ff"/>
          <circle cx="50" cy="36" r="10" fill="white"/>
          <rect x="42" y="46" width="16" height="32" rx="8" fill="white"/>
          <rect x="44" y="76" width="6" height="16" fill="white"/>
          <rect x="50" y="76" width="6" height="16" fill="white"/>
          <rect x="36" y="50" width="28" height="24" rx="6" fill="#a8d8ff"/>
          <rect x="40" y="74" width="20" height="8" rx="3" fill="white"/>
          <rect x="42" y="50" width="4" height="20" fill="white"/>
          <rect x="54" y="50" width="4" height="20" fill="white"/>
        </svg>
            </div>
            <div>
                <div class="logo-text">Student<span>Shield</span></div>
                <div class="tagline">School Health Guardian</div>
            </div>
        </a>

        <!-- Menu & Login – always visible -->
        <div class="nav-links">
            <a href="#">Home</a>
            <a href="#">Services</a>
            <a href="#">About</a>
            <a href="#" class="login-btn">Login</a>
        </div>
    </nav>

</body>

</html>