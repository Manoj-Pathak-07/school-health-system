// dashboard.js - Charts and Dashboard Interactions
class DashboardCharts {
    constructor() {
        this.colors = {
            primary: '#1976d2',
            secondary: '#2196f3',
            success: '#4caf50',
            warning: '#ff9800',
            error: '#f44336'
        };
        this.init();
    }

    init() {
        this.createScreeningChart();
        this.createHealthChart();
        this.createProgressChart();
        this.initAnimations();
    }

    createScreeningChart() {
        const ctx = document.getElementById('screeningChart');
        if (!ctx) return;

        const data = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Screenings Completed',
                data: [65, 59, 80, 81, 56, 55],
                backgroundColor: this.colors.primary,
                borderColor: this.colors.primary,
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        };

        this.renderLineChart(ctx, data, 'Screenings Overview');
    }

    createHealthChart() {
        const ctx = document.getElementById('healthChart');
        if (!ctx) return;

        const data = {
            labels: ['Normal', 'Vision Issues', 'Dental', 'Hearing', 'Other'],
            datasets: [{
                data: [45, 15, 20, 10, 10],
                backgroundColor: [
                    this.colors.success,
                    this.colors.warning,
                    this.colors.primary,
                    this.colors.secondary,
                    this.colors.error
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        };

        this.renderDoughnutChart(ctx, data, 'Health Issues Distribution');
    }

    createProgressChart() {
        const ctx = document.getElementById('progressChart');
        if (!ctx) return;

        const data = {
            labels: ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5'],
            datasets: [{
                label: 'Screening Progress',
                data: [85, 70, 90, 60, 75],
                backgroundColor: this.colors.secondary,
                borderColor: this.colors.primary,
                borderWidth: 2
            }]
        };

        this.renderBarChart(ctx, data, 'Grade-wise Progress');
    }

    renderLineChart(ctx, data, title) {
        new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    renderDoughnutChart(ctx, data, title) {
        new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 16, weight: '600' }
                    }
                },
                cutout: '60%'
            }
        });
    }

    renderBarChart(ctx, data, title) {
        new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 16, weight: '600' }
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    initAnimations() {
        // Animate stats counters
        this.animateValue('.stat-number');
        
        // Add intersection observer for scroll animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.stat-card, .chart-card, .action-btn').forEach(el => {
            observer.observe(el);
        });
    }

    animateValue(selector) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            const finalValue = parseInt(element.textContent);
            let currentValue = 0;
            const duration = 2000;
            const increment = finalValue / (duration / 16);
            
            const timer = setInterval(() => {
                currentValue += increment;
                if (currentValue >= finalValue) {
                    element.textContent = finalValue.toLocaleString();
                    clearInterval(timer);
                } else {
                    element.textContent = Math.floor(currentValue).toLocaleString();
                }
            }, 16);
        });
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    new DashboardCharts();
    
    // Mobile menu toggle
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (mobileMenuToggle && sidebar) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-open');
        });
    }
    
    // Print functionality
    const printButtons = document.querySelectorAll('.print-btn');
    printButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            window.print();
        });
    });
    
    // Notification handling
    const notificationItems = document.querySelectorAll('.notification-item');
    notificationItems.forEach(item => {
        item.addEventListener('click', function() {
            this.classList.remove('unread');
        });
    });
});