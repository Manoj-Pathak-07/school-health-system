<?php
// config.php
session_start();

// Database Configuration
$host = 'localhost';
$dbname = 'school_health_system';
$username = 'root';
$password = 'root';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Authentication Functions
function check_auth() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
        header("Location: ../login.php");
        exit;
    }
}

function require_role($allowed_roles) {
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], (array)$allowed_roles)) {
        header("Location: ../login.php");
        exit;
    }
}

// Database Functions for Dashboard Data
function getSchoolStats($school_id) {
    global $pdo;
    
    try {
        // Get total students
        $sql = "SELECT COUNT(*) as total_students FROM students WHERE school_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$school_id]);
        $students = $stmt->fetch();
        
        // Get total screenings
        $sql = "SELECT COUNT(*) as total_screenings FROM screenings WHERE school_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$school_id]);
        $screenings = $stmt->fetch();
        
        // Get recent screenings (last 30 days)
        $sql = "SELECT COUNT(*) as recent_screenings FROM screenings 
                WHERE school_id = ? AND screening_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$school_id]);
        $recent = $stmt->fetch();
        
        return [
            'total_students' => $students['total_students'] ?? 0,
            'total_screenings' => $screenings['total_screenings'] ?? 0,
            'recent_screenings' => $recent['recent_screenings'] ?? 0
        ];
        
    } catch (PDOException $e) {
        error_log("Database error in getSchoolStats: " . $e->getMessage());
        return [
            'total_students' => 0,
            'total_screenings' => 0,
            'recent_screenings' => 0
        ];
    }
}

function getDoctorStats($doctor_id) {
    global $pdo;
    
    $stats = [];
    
    // Today's Appointments
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM screening_schedule 
                          WHERE doctor_id = ? AND schedule_date = CURDATE()");
    $stmt->execute([$doctor_id]);
    $stats['today_appointments'] = $stmt->fetchColumn();
    
    // Completed Today
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM screenings 
                          WHERE doctor_id = ? AND DATE(created_at) = CURDATE()");
    $stmt->execute([$doctor_id]);
    $stats['completed_today'] = $stmt->fetchColumn();
    
    // Pending Reports
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM screenings 
                          WHERE doctor_id = ? AND needs_followup = 1");
    $stmt->execute([$doctor_id]);
    $stats['pending_reports'] = $stmt->fetchColumn();
    
    // Referred Students
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT student_id) as total FROM screenings 
                          WHERE doctor_id = ? AND referral_required = 1");
    $stmt->execute([$doctor_id]);
    $stats['referred_students'] = $stmt->fetchColumn();
    
    return $stats;
}

function getStudentData($student_id) {
    global $pdo;
    
    $data = [];
    
    // Basic student info
    $stmt = $pdo->prepare("SELECT s.*, u.full_name, u.email 
                          FROM students s 
                          JOIN users u ON s.user_id = u.id 
                          WHERE s.id = ?");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch();
    
    $data['name'] = $student['full_name'];
    $data['grade'] = $student['grade'];
    $data['email'] = $student['email'];
    
    // Latest screening data
    $stmt = $pdo->prepare("SELECT * FROM screenings 
                          WHERE student_id = ? 
                          ORDER BY screening_date DESC 
                          LIMIT 1");
    $stmt->execute([$student_id]);
    $screening = $stmt->fetch();
    
    if ($screening) {
        $data['last_screening'] = $screening['screening_date'];
        $data['bmi'] = $screening['bmi'] ?? 'N/A';
        $data['vision_status'] = 'Normal';
        $data['dental_status'] = 'Good';
    } else {
        $data['last_screening'] = 'No screenings yet';
        $data['bmi'] = 'N/A';
        $data['vision_status'] = 'Not screened';
        $data['dental_status'] = 'Not screened';
    }
    
    // Next screening
    $stmt = $pdo->prepare("SELECT schedule_date FROM screening_schedule 
                          WHERE student_id = ? AND schedule_date >= CURDATE() 
                          ORDER BY schedule_date ASC 
                          LIMIT 1");
    $stmt->execute([$student_id]);
    $next_screening = $stmt->fetchColumn();
    $data['next_screening'] = $next_screening ?: 'Not scheduled';
    
    return $data;
}

function getRecentActivities($school_id, $limit = 5) {
    global $pdo;
    
    try {
        $sql = "SELECT s.name as student_name, s.grade, sc.screening_date, 
                      CASE WHEN sc.needs_followup = 1 THEN 'pending' ELSE 'completed' END as status,
                      u.full_name as doctor_name
               FROM screenings sc
               JOIN students s ON sc.student_id = s.id
               JOIN users u ON sc.doctor_id = u.id
               WHERE sc.school_id = ?
               ORDER BY sc.screening_date DESC 
               LIMIT " . (int)$limit;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$school_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Database error in getRecentActivities: " . $e->getMessage());
        return [];
    }
}

function getTodaySchedule($doctor_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT ss.schedule_time, s.name as student_name, s.grade, ss.screening_type
                          FROM screening_schedule ss
                          JOIN students s ON ss.student_id = s.id
                          WHERE ss.doctor_id = ? AND ss.schedule_date = CURDATE()
                          ORDER BY ss.schedule_time ASC");
    $stmt->execute([$doctor_id]);
    return $stmt->fetchAll();
}
?>