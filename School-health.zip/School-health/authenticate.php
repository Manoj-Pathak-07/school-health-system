<?php
session_start();

// Try different possible paths for config.php
$possible_paths = [
    __DIR__ . '/config.php',           // Same directory
    __DIR__ . '/../config.php',        // One level up
    __DIR__ . '/../../config.php',     // Two levels up (what you were trying)
];

$config_loaded = false;
foreach ($possible_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

if (!$config_loaded) {
    die("Error: config.php file not found. Please check your file structure.");
}

if ($_POST) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    try {
        // Your login code here...
        $sql = "SELECT 
                    u.*,
                    s.id AS school_id,
                    s.school_name,
                    st.student_code AS student_code,
                    st.grade AS student_grade,
                    st.school_id AS student_school_id
                FROM users u
                LEFT JOIN schools s ON u.id = s.user_id
                LEFT JOIN students st ON u.id = st.user_id
                WHERE u.email = ? 
                AND u.is_active = TRUE
                LIMIT 1";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            header("Location: login.php?error=invalid");
            exit;
        }

        // Password check
        if (!($user['password'] === $password || password_verify($password, $user['password']))) {
            header("Location: login.php?error=invalid");
            exit;
        }

        // Login success
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];

        // Role-based redirects
        if ($user['role'] === 'school') {
            $_SESSION['school_id'] = $user['school_id'];
            $_SESSION['school_name'] = $user['school_name'];
            header("Location: dashboard/school/school_dashboard.php");
            exit;
        }

        if ($user['role'] === 'student') {
            $_SESSION['student_code'] = $user['student_code'];
            $_SESSION['grade'] = $user['student_grade'];
            $_SESSION['school_id'] = $user['student_school_id'];
            header("Location: dashboard/student/student_dashboard.php");
            exit;
        }

        if ($user['role'] === 'doctor') {
            header("Location: dashboard/doctor/doctor_dashboard.php");
            exit;
        }

        header("Location: login.php?error=role");
        exit;

    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        header("Location: login.php?error=system");
        exit;
    }
} else {
    header("Location: login.php");
    exit;
}
?>